<style type="text/css">
	tr:nth-child(even) {background: #CCC}
	tr:nth-child(odd) {background: #FFF}
</style>
<?php session_start();
	if(!isset($_SESSION["uid"]))
	{
		header("location:login.php");
		exit;
	}
	

?>

<html>
	<head>
		 <title></title>
			  <meta charset="utf-8">
			  <meta name="viewport" content="width=device-width, initial-scale=1">
			  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
			  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
			  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>
<body>
		<nav class="navbar navbar-default">
		  <div class="container-fluid">
    	  <ul class="nav navbar-nav">
		      <li><a href="dashboard.php">Home</a></li>
		      <li><a href="manage_category.php">Manage Category</a></li>
		      <li><a href="manage_sub_category.php">Manage Sub-category</a></li>
		      <li><a href="manage_product.php">Manage Product</a></li>
		      <li class="active"><a href="manage_customers.php">Manage Customers</a></li>
		      <li><a href="logout.php">Logout</a></li>
    	  </ul>
  		</div>
        </nav>
  
 
 <?php 
$con = mysql_connect("localhost", "root","") or die("Unable to connect to MySQL");
$db= mysql_select_db("catalog_management") or die("unable to connect");


$res=mysql_query("SELECT * FROM formtest"); 
//$row = mysql_fetch_array($res); 
?>
<h3 style="text-align:center">Manage Customers</h3>
<table border='1' align="center">
	<tr>
		<th>Id</th>
		<th>Full Name</th>
		<th>Dob</th>
		<th>gender</th>
		<th>State</th>
		<th>File</th>
		<th>Edit/Delete</th>
	</tr>

<?php while(list($a,$b,$c,$d,$e,$f)=mysql_fetch_array($res)) { ?>
	<tr>
		<td><?php  echo $a;?></td>
		<td><?php  echo $b;?></td>
		<td><?php  echo $c;?></td>
		<td><?php  echo $d;?></td>
		<td><?php  echo $e;?></td>
		<td><?php  echo "<img src='uploads/".$f."' width='100' height='100'/>" ?></td>
		<td> 
			<a href='customers_insert_update.php?chk=<?php echo $a; ?>'><img src="edit2.png" width='30px' height='30spx'></a>    
			<a href='manage_customers.php?chkid=<?php echo $a; ?>'><img src="delete1.png" width='30px' height='30spx'></a> 
		</td>
                
<?php } ?>
	</tr> 

	
			
		
</table><br><br>
<center><button><a href='customers_insert_update.php'>Add new</a></button></center>

<?php	
if(isset($_GET['chkid']))
{
$a= $_GET['chkid'];	
mysql_query("delete FROM `formtest` where id = $a");
echo "records deleted";
echo'<script>window.location="manage_customers.php";</script>';
}
?>




</body>
