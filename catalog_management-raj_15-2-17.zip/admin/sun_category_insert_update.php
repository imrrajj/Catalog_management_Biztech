<form action="" method="POST" name="form" enctype="multipart/form-data" >
		<table border=0px>
			<tr>
				<td>Sub Category Name</td>
				<td><input type="text" name="scname"></td>
			</tr>
			<tr>
				<td>Description</td>
				<td><textarea rows="5" cols="50" name="de"></textarea></td>
			</tr>
			<tr>
				<td>Short Description</td>
				<td><textarea rows="4" cols="40" name="sde"></textarea></td>
			</tr>
			<tr>
				<td>Status</td>
				<td><input type="radio" value="0" name="status">Inactive
				<input type="radio" value="1" name="status">Active</td>
			</tr>
			<tr>
				<td>Upload Image</td>
				<td><input type='file' name='image'></td>
			</tr>
		</table>
		<input type="submit" value="ADD" name="submit" >
</form>

<?php

if(isset($_POST['submit'])){	
	$cname=$_POST['scname'];
	$de=$_POST['de'];
	$sde=$_POST['sde'];
	$status=$_POST['status'];
	$file = rand(1000,100000)."-".$_FILES['image']['name'];
	//print_r($_POST); die;
 	$file_loc = $_FILES['image']['tmp_name'];
 	$file_size = $_FILES['image']['size'];
 	$file_type = $_FILES['image']['type'];
 	$folder="uploads/";
 	move_uploaded_file($_FILES['image']['tmp_name'], $folder.$file);

$con = mysql_connect("localhost", "root","") or die("Unable to connect to MySQL");
$db= mysql_select_db("catalog_management") or die("unable to connect");

echo $ins="INSERT INTO `categories`(`cat_name`, `description`, `sdescription`, `status`, `file`) VALUES ('$cname','$de','$sde','$status','$file')";
//print_r($ins);die;
mysql_query($ins);

header("location:manage_category.php");
}
?>