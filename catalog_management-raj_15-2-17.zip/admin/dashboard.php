<?php
session_start();
if (!isset($_SESSION["uid"])) {
    header("location:login.php");
    exit;
}
?>

<html>
    <head>
        <title></title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
    <body>
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="dashboard.php">Home</a></li>
                    <li><a href="manage_category.php">Manage Category</a></li>
                    <li><a href="manage_sub_category.php">Manage Sub-category</a></li>
                    <li><a href="manage_product.php">Manage Product</a></li>
                    <li><a href="manage_customers.php">Manage Customers</a></li>
                    <li><a href="logout.php">Logout</a></li>
                    <li><a></a></li>
                    <li><a></a></li>
                    <li><a></a></li>
                    <li><a></a></li>
                    <li><a></a></li>
                    <li><a></a></li>
                    <li><a></a></li>
                    <li><a> <?php echo "Welcome " . $_SESSION["uname"]; ?></a></li>
                </ul>
            </div>
        </nav>

        <form action="dashboard.php" method="POST">
            <marquee scrollamount="5" direction=right behavior=alternate><h1>Welcome to Catalog Management</h1></marquee>
        </form>

        <?php
        $con = mysql_connect("localhost", "root", "") or die("Unable to connect to MySQL");
        $db = mysql_select_db("catalog_management") or die("unable to connect");
        $sql1 = "select count(*) from categories where p_id=0";
        $res1 = mysql_query($sql1);
        $row1 = mysql_fetch_array($res1);
        
        $sql = "select count(*) from categories where p_id>0";
        $res = mysql_query($sql);
        $row = mysql_fetch_array($res);
        
        $sql2 = "select count(*) from product";
        $res2 = mysql_query($sql2);
        $row2 = mysql_fetch_array($res2);
        
        $sql3 = "select count(*) from login_user";
        $res3 = mysql_query($sql3);
        $row3 = mysql_fetch_array($res3);
        //print_r($row);
        ?>
        <div class="container">
            <div class="table-responsive">          
                <table class="table">
                    <thead>
                        
                    </thead>
                    <tbody>
                        <tr>
                            <td>Categories</td>
                            <td><?php echo $row1[0]; ?></td>
                        </tr>
                        <tr>
                            <td>Subcategories</td>
                            <td><?php echo $row[0]; ?></td>
                        </tr>
                        <tr>
                            <td>Products</td>
                            <td><?php echo $row2[0]; ?></td>
                        </tr>
                        <tr>
                            <td>users</td>
                            <td><?php echo $row3[0]; ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

    </body>
</html>