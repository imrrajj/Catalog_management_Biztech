<html>
    <head>
        <title></title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="jquery.min.js"></script>
        <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>-->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <style type="text/css">
            textarea
            {
                overflow-y: scroll;
            }
            .error{
                color:red;
            }
        </style>
        <!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>-->
        <script type="text/javascript" src="jquery.validate.min.js"></script>
        <script type="text/javascript">

            $(function () {
                $("form[name='form']").validate({
                    rules: {
                        prname: "required",
                        de: "required",
                        sde: "required",
                        price: "required",
                        image: "required",
                        category: "required",
                        sub_category: "required"
                    },
                    messages: {
                        prname: "enter product name",
                        de: "enter description",
                        sde: "enter short description",
                        price: "enter price",
                        image: "select an image",
                        category: "select category",
                        sub_category: "select sub-category"
                    }
                });
//            });

//            $(document).ready(function () {
                $("#category").change(function ()
                {
                    var catid = $("#category").val();
                    if (catid)
                    {
                        $.ajax
                                ({
                                    type: "POST",
                                    url: "ajax.php",
                                    data: 'id=' + catid,
                                    cache: false,
                                    success: function (html)
                                    {
                                        $("#sub_category").html(html);

                                    }
                                });
                    }
                    else
                    {
                        $('#sub_category').html('<option value="">select category</option>');
                    }
                    ;

                });
            });
        </script>
    </head>
    <body>
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <ul class="nav navbar-nav">
                    <li><a href="dashboard.php">Home</a></li>
                    <li><a href="manage_category.php">Manage Category</a></li>
                    <li><a href="manage_sub_category.php">Manage Sub-category</a></li>
                    <li class="active"><a href="manage_product.php">Manage Product</a></li>
                    <li><a href="manage_customers.php">Manage Customers</a></li>
                </ul>
            </div>
        </nav>
    </body>
</html>

<!DOCTYPE html>
<html>
    <head>
        <title></title>


        <script type="text/javascript">
//            $(document).ready(function () {
//                $("#category").change(function ()
//                {
//                    var catid = $("#category").val();
//                    if (catid)
//                    {
//                        $.ajax
//                                ({
//                                    type: "POST",
//                                    url: "ajax.php",
//                                    data: 'id=' + catid,
//                                    cache: false,
//                                    success: function (html)
//                                    {
//                                        $("#sub_category").html(html);
//
//                                    }
//                                });
//                    }
//                    else
//                    {
//                        $('#sub_category').html('<option value="">select category</option>');
//                    }
//                    ;
//
//                });
//            });
        </script>

    </head>
    <body>
        <?php
        if (!isset($_GET['chk'])) {
            ?>
            <form action="" method="POST" name="form" enctype="multipart/form-data" >
                <table border=0px width="400">
                    <tr>
                        <td>Product Name</td>
                        <td><input type="text" name="prname"></td>
                    </tr>
                    <tr>
                        <td>Description</td>
                        <td><textarea rows="5" cols="20" name="de"></textarea></td>
                    </tr>
                    <tr>
                        <td>Short Description</td>
                        <td><textarea rows="4" cols="15" name="sde"></textarea></td>
                    </tr>
                    <tr>
                        <td>Price</td>
                        <td><input type="number" name="price"></td>
                    </tr>
                    <tr>
                        <td>Upload Image</td>
                        <td><input type='file' name='image'></td>
                    </tr>
                    <tr>
                        <td>Category</td>
                        <td>
                            <select name="category" id="category">
                                <option value="">Select Category</option>
                                <?php
                                $con = mysql_connect("localhost", "root", "") or die("Unable to connect to MySQL");
                                $db = mysql_select_db("catalog_management") or die("unable to connect");

                                $sql = "SELECT * FROM `categories` where p_id=0";
                                $query = mysql_query($sql);
                                while ($row1 = mysql_fetch_array($query)) {
                                    ?>
                                    <option value="<?php echo $row1['cat_id']; ?>"><?php echo $row1['cat_name']; ?></option>
                                <?php } ?>
                            </select>

                        </td>
                    </tr>
                    <tr>
                        <td>Sub Category</td>
                        <td>
                            <select name="subcategory" id="sub_category">
                                <option value="">select subcategory</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            status
                        </td>
                        <td><input type="radio" value="0" checked="true" name="pr_status">Inactive
                            <input type="radio" value="1" name="pr_status">Active</td>
                    </tr>
                    <tr>
                        <td>
                            Inventory
                        </td>
                        <td>
                            <input type="number" name="inventory">
                        </td>
                    </tr>
                </table>
                <input type="submit" value="ADD" name="submit" onclick="validate()">
            </form>
            <?php
        } else {
            $con = mysql_connect("localhost", "root", "");
            $db = mysql_select_db("catalog_management");
            $b = $_GET['chk'];
            $sql = "SELECT * FROM product where pr_id = $b";
            $res = mysql_query($sql);
            $row = mysql_fetch_array($res);
            ?>
            <form action="" method="POST" name="form" enctype="multipart/form-data" >
                <table border=0px>

                    <tr>
                        <td>Product Name</td>
                        <td><input type="text" name="prname" value="<?php echo $row['Name']; ?>"></td>
                    </tr>
                    <tr>
                        <td>Description</td>
                        <td><textarea rows="5" cols="50" name="de"><?php echo $row['Description']; ?></textarea></td>
                    </tr>
                    <tr>
                        <td>Short Description</td>
                        <td><textarea rows="4" cols="40" name="sde"><?php echo $row['Short_description']; ?></textarea></td>
                    </tr>
                    <tr>
                        <td>Price</td>
                        <td><input type="number" name="price" value='<?php echo $row['price']; ?>' ></td>
                    </tr>
                    <tr>
                        <td>Upload Image</td>
                        <td><input type='file' name='image'><img src='uploads/<?php echo $row['file']; ?>' width="200" height="200"></td>
                    </tr>
                    <tr>
                        <td>Category</td>
                        <td>
                            <select name="category" id="category">
                                <option value="">Select Category</option>
                                <?php
                                $con = mysql_connect("localhost", "root", "") or die("Unable to connect to MySQL");
                                $db = mysql_select_db("catalog_management") or die("unable to connect");

                                $sql = "SELECT * FROM `categories` where p_id=0";
                                $query = mysql_query($sql);
                                while ($row1 = mysql_fetch_array($query)) {
                                    ?>
                                    <option value="<?php echo $row1['cat_id']; ?>"><?php echo $row1['cat_name']; ?></option>
                                <?php } ?>
                            </select>

                        </td>
                    </tr>
                    <tr>
                        <td>Sub Category</td>
                        <td>
                            <select name="subcategory" id="sub_category">
                                <option value="">select subcategory</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            status
                        <td><input type="radio" value="0" name="status" <?php echo ($row['p_status'] == "0") ? 'checked="checked"' : ""; ?>>Inactive
                            <input type="radio" value="1" name="status" <?php echo ($row['p_status'] == "1") ? 'checked="checked"' : ""; ?>>Active</td>
                    </tr>
                    <tr>
                        <td>
                            Inventory
                        </td>
                        <td>
                            <input type="number" name="inventory" value='<?php echo $row['Inventory']; ?>'>
                        </td>
                    </tr>
                </table>
                <input type="submit" value="UPDATE" name="upd" >
            </form>
        <?php } ?>  
        <?php
        if (isset($_POST['submit'])) {
            $prname = $_POST['prname'];
            $de = $_POST['de'];
            $sde = $_POST['sde'];
            $price = $_POST['price'];
            $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
            $category = $_POST['category'];
            $subcategory = $_POST['subcategory'];
            $inventory = $_POST['inventory'];
            $p_status = $_POST['pr_status'];
            $file_loc = $_FILES['image']['tmp_name'];
            $file_size = $_FILES['image']['size'];
            $file_type = $_FILES['image']['type'];
            $folder = "uploads/";
            move_uploaded_file($_FILES['image']['tmp_name'], $folder . $file);
//print_r($_POST); die;	
            $con = mysql_connect("localhost", "root", "") or die("Unable to connect to MySQL");
            $db = mysql_select_db("catalog_management") or die("unable to connect");
//echo $p_status; 
//exit; 
            $ins = "INSERT INTO `product`( `Name`, `Description`, `Short_description`, `price`, `file`, `category`, `sub_category`,`p_status`,`inventory` ) VALUES ('$prname','$de','$sde','$price','$file','$category','$subcategory','$p_status','$inventory')";
//print_r($ins);die;
            mysql_query($ins);

            echo'<script>window.location="manage_product.php";</script>';
        }
        ?>

        <?php
        if (isset($_POST['upd'])) {
            $con = mysql_connect("localhost", "root", "") or die("Unable to connect to MySQL");
            $db = mysql_select_db("catalog_management") or die("unable to connect");

            $prname = $_POST['prname'];
            $de = $_POST['de'];
            $sde = $_POST['sde'];
            $price = $_POST['price'];
            $category = $_POST['category'];
            $scategory = $_POST['scategory'];
            $p_status = $_POST['status'];
            $inventory = $_POST['inventory'];


            //print_r($_FILES['image']['name']);
            //print_r($_POST); die;

            if ($_FILES['image']['name']) {
                $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
                $file_loc = $_FILES['image']['tmp_name'];
                $file_size = $_FILES['image']['size'];
                $file_type = $_FILES['image']['type'];
                $folder = "uploads/";
                move_uploaded_file($_FILES['image']['tmp_name'], $folder . $file);
                $upd = "UPDATE `product` SET `Name`='$prname',`Description`='$de',`Short_description`='$sde',`price`='$price',`file`='$file',`category`='$category',`sub_category`='$scategory',`p_status` ='$p_status',`Inventory`='$inventory' WHERE pr_id=" . $_GET['chk'] . "";
                mysql_query($upd);
                echo'<script>window.location="manage_product.php";</script>';
            }
//                 } else {
//                $upd = "UPDATE `product` SET `Name`='$prname',`Description`='$de',`Short_description`='$sde',`price`='$price',`category`='$category',`sub_category`='$scategory' ,`p_status`='$p_status' WHERE pr_id='$pr_id'";
//                //print_r($upd); die;
//                mysql_query($upd);
//                echo'<script>window.location="manage_product.php";</script>';
//            }
            //die;
//$upd="UPDATE `product` SET `Name`='$prname',`Description`='$de',`Short_description`='$sde',`price`='$price',`category`='$category',`sub_category`='$scategory' WHERE pr_id='$b'";
//print_r($upd); die;
//mysql_query($upd);
//echo "updated";
//echo'<script>window.location="manage_product.php";</script>';
        }
        ?>
    </body>
</html>