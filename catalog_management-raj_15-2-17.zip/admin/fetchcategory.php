<?php
	include "header.php";
?>
<html>
<head>

<script src="jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){

 $("#category").change(function()
 {
  var catid=$("#category").val();

  
  if (catid) {
    $.ajax
  ({
   type: "POST",
   url: "ajax.php",
   data: 'id='+catid,
   cache: false,
   success: function(html)
   {
      $("#sub_category").html(html);

   } 
   });
  } else{
    $('#sub_category').html('<option value="">select category</option>');
  }; 
  
  });
 });
</script>
