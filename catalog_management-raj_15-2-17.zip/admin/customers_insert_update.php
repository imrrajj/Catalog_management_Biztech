<html>
    <head>
        <title></title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <style type="text/css">
            textarea
            {
                overflow-y: scroll;
            }
            .error{
                color:red;
            }
        </style>

        <script type="text/javascript" src="jquery.validate.min.js"></script>
        <script type="text/javascript">
            $(function () {
                $("form[name='form']").validate({
                    rules: {
                        fname: "required",
                        mname: "required",
                        lname: "required",
                        image: "required",
                        day: "required",
                        month: "required",
                        year: "required",
                        country: "required",
                        state: "required",
                        city: "required",
                        gender: "required"

                    },
                    messages: {
                        fname: "enter first name",
                        mname: "enter middle name",
                        lname: "enter last name",
                        image: "select image",
                        day: {required: "Please Select Dateofbirth", },
                        month: {required: "Please Select Dateofbirth", },
                        year: {required: "Please Select Dateofbirth", },
                        country: "select country",
                        state: "select state",
                        city: "select city",
                        gender: "select gender"
                    },
                    groups: {
                        birthday: "day month year",
                    },
                    errorPlacement: function (error, element) {
                        if (element.attr("name") == "day" || element.attr("name") == "month" || element.attr("name") == "year")
                            error.insertAfter("#day");
                        else
                            error.insertAfter(element);
                    },
                });
            });</script>
    </head>
    <body>
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <ul class="nav navbar-nav">
                    <li><a href="dashboard.php">Home</a></li>
                    <li><a href="manage_category.php">Manage Category</a></li>
                    <li><a href="manage_sub_category.php">Manage Sub-category</a></li>
                    <li><a href="manage_product.php">Manage Product</a></li>
                    <li class="active"><a href="manage_customers.php">Manage Customers</a></li>
                </ul>
            </div>
        </nav>
    </body>
</html>

<html>
    <head></head>
    <body>

        <?php if (!isset($_GET['chk'])) { ?>

            <form action="" method="POST" name="form" id="form1" enctype="multipart/form-data">
                <table border=0px width="400">
                    <tr>
                        <td>First name</td>
                        <td><input type="text" name="fname"></td>
                    </tr>
                    <tr>
                        <td>Middle name</td>
                        <td><input type="text" name="mname" ></td>
                    </tr>
                    <tr>
                        <td>Last name</td>
                        <td><input type="text" name="lname" ></td>
                    </tr>
                    <tr>
                        <td name="dob">DOB</td>
    <!--                        <td>
                            <select id="day" name="day" >
                                <option value="">Date</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                            </select>
                            <select id="month" name="month">
                                <option value="">Month</option>
                                <option value="1">Jan</option>
                                <option value="2">Feb</option>
                            </select>
                            <select id="year" name="year">
                                <option value="">Year</option>
                                <option value="1995">1995</option>
                                <option value="1996">1996</option>
                            </select>
                        </td>-->

                        <td>
                            <select name="day" id="day" >
                                <option value="">Date</option>
                                <?php
                                for ($i = 1; $i <= 31; $i++) {
                                    ?>
                                    <option value="<?php echo $i; ?>"><?php echo $i ?></option>
                                <?php }
                                ?>
                            </select>

                            <?php
                            echo "<select name='month' >";
                            echo "<option value=''>Month</option>";
                            for ($i = 1; $i <= 12; $i++) {
                                $month = date('F', strtotime("first day of +$i month"));

                                echo "<option value=0$i>$month</option> ";
                            }
                            echo "</select>";
                            ?>

                            <select name="year" >
                                <option value="">year</option>
                                <?php
                                for ($i = 2000; $i <= 2017; $i++) {
                                    ?>
                                    <option value="<?php echo $i; ?>"><?php echo $i ?></option>
                                <?php }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Gender</td>
                        <td><input type="radio" name="gender" value="Male">Male
                            <input type="radio" name="gender" value="Female">Female</td>
                    </tr>
                    <tr><td>City</td>
                        <td>
                            <select id="city" name="city">
                                <option value="">City</option>
                                <option value="1">Ahmedabad</option>
                                <option value="2">Pune</option>
                            </select></td>
                    </tr>
                    <tr><td>State</td>
                        <td>
                            <select id="state" name="state">
                                <option value="">State</option>
                                <option value="Gujarat">Gujarat</option>
                                <option value="Maharashtra">Maharashtra</option>
                            </select></td>
                    </tr>
                    <tr><td>Country</td>
                        <td>
                            <select id="country" name="country">
                                <option value="">Country</option>
                                <option value="1">India</option>
                                <option value="2">Canada</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Upload Image</td>
                        <td><input type='file' name='image'></td>
                    </tr>
                </table>
                <input type="checkbox" checked='true'>Accept Terms <br>
                <input type="submit" value="ADD" name="submit" onclick="validate()">
            </form>
            <?php
        } else {
            $con = mysql_connect("localhost", "root", "");
            $db = mysql_select_db("catalog_management");
            $b = $_GET['chk'];
            $sql = "SELECT * FROM formtest where id = $b";
            $res = mysql_query($sql);
            $array = mysql_fetch_array($res);

            $fullname = $array[1];
            $exp = explode(" ", $fullname);

            $dob = $array[2];
            $dt = explode("-", $dob);
            ?>
            <form action="customers_insert_update.php?chk=<?php echo $array[0]; ?>" method="POST" name="formtest" enctype="multipart/form-data" >
                <table border=0px>
                    <tr>
                        <td>First name</td>
                        <td><input type="text" name="fname" value="<?php echo $exp[0]; ?>"></td>
                    </tr>
                    <tr>
                        <td>Middle name</td>
                        <td><input type="text" name="mname" value="<?php echo $exp[1]; ?>"></td>
                    </tr>
                    <tr>
                        <td>Last name</td>
                        <td><input type="text" name="lname" value="<?php echo $exp[2]; ?>"></td>
                    </tr>
                    <tr>
                        <td>DOB</td>
                        <td>

                            <select id="day" name="day">
                                <option value="">Date</option>
                                <option value="1" <?php echo ($dt[2] == 01) ? 'selected="selected"' : ""; ?>>1</option>
                                <option value="2" <?php echo ($dt[2] == 02) ? 'selected="selected"' : ""; ?>>2</option>
                            </select>
                            <select id="month" name="month">
                                <option value="">Month</option>
                                <option value="1" <?php echo ($dt[1] == 01) ? 'selected="selected"' : ""; ?> >Jan</option>
                                <option value="2" <?php echo ($dt[1] == 02) ? 'selected="selected"' : ""; ?> >Feb</option>
                            </select>
                            <select id="year" name="year">
                                <option value="" >Year</option>
                                <option value="1995" <?php echo ($dt[0] == 1995) ? 'selected="selected"' : ""; ?> >1995</option>
                                <option value="1996" <?php echo ($dt[0] == 1996) ? 'selected="selected"' : ""; ?>>1996</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Gender</td>
                        <td><input type="radio" name="gender" value="Male" checked='true' <?php echo ($array['gender'] == "Male") ? 'checked="checked"' : ""; ?>>Male
                            <input type="radio" name="gender" value="Female" <?php echo ($array['gender'] == "Female") ? 'checked="checked"' : ""; ?>>Female</td>
                    </tr>
                    <tr><td>City</td>
                        <td>
                            <select id="city" name="city">
                                <option value="">City</option>
                                <option value="1">Ahmedabad</option>
                                <option value="2">Pune</option>
                            </select></td>
                    </tr>
                    <tr><td>State</td>
                        <td>
                            <select id="state" name="state">
                                <option value="">State</option>
                                <option value="Gujarat" <?php echo ($array['state'] == "Gujarat") ? 'selected="selected"' : ""; ?>>Gujarat</option>
                                <option value="Maharashtra" <?php echo ($array['state'] == "Maharashtra") ? 'selected="selected"' : ""; ?>>Maharashtra</option>
                            </select></td>
                    </tr>
                    <tr><td>Country</td>
                        <td>
                            <select id="country" name="country">
                                <option value="">Country</option>
                                <option value="1">India</option>
                                <option value="2">Canada</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Upload Image</td>

                        <td><input type='file' name='image' value="<?php echo $array['file']; ?>"></td>
                        <td><img src='uploads/<?php echo $array['file']; ?>' width='100' height='100'></td>
                    </tr>
                </table>
                <input type="checkbox" checked='true'>Accept Terms <br>
                <input type="submit" value="UPDATE" name="upd">
            </form>
        <?php } ?>
    </body>
</html>


<?php
if (isset($_POST['upd'])) {
    $id = $_REQUEST['chk'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname = $_POST['lname'];
    $dob;
    $day = $_POST['day'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $gender = $_POST['gender'];
    $state = $_POST['state'];
    //print_r($_POST); die;
    $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
    //print_r($_POST); die;
    $file_loc = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_type = $_FILES['image']['type'];
    $folder = "uploads/";
    move_uploaded_file($_FILES['image']['tmp_name'], $folder . $file);

    $con = mysql_connect("localhost", "root", "") or die("Unable to connect to MySQL");
    $db = mysql_select_db("catalog_management") or die("unable to connect");

    $upd = "UPDATE `formtest` SET `fullname`='$fname $mname $lname',`dob`='$year-$month-$day',`gender`='$gender',`state`='$state',`file`='$file'	 WHERE id='$b'";
//print_r($upd); die;
    mysql_query($upd);
    echo "updated";
    echo'<script>window.location="manage_customers.php";</script>';
}

if (isset($_POST['submit'])) {
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname = $_POST['lname'];
    $dob;
    $day = $_POST['day'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    //$gender=$_POST['gender'];
    $state = $_POST['state'];
    $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
    //print_r($_POST); die;
    $file_loc = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_type = $_FILES['image']['type'];
    $folder = "uploads/";
    move_uploaded_file($_FILES['image']['tmp_name'], $folder . $file);

    $con = mysql_connect("localhost", "root", "") or die("Unable to connect to MySQL");
    $db = mysql_select_db("catalog_management") or die("unable to connect");

    $ins = "INSERT INTO `formtest`(`fullname`, `dob`, `gender`, `state`, `file`) VALUES ('$fname $mname $lname','$year-$month-$day','" . $_POST['gender'] . "','$state','$file')";
//print_r($ins);die;
    mysql_query($ins);

    echo'<script>window.location="manage_customers.php";</script>';
}
?>

