 <?php

$con = mysql_connect("localhost", "root","") or die("Unable to connect to MySQL");
$db= mysql_select_db("catalog_management") or die("unable to connect");

if (isset($_POST["id"]) && !empty($_POST["id"])) {
//echo $_POST['id']; die;
    $query = mysql_query("SELECT * FROM categories WHERE p_id =" . $_POST['id'] . "");
    $rowCount = mysql_num_rows($query);
   
    if ($rowCount > 0) {

        echo '<option value="">Select subcategory</option>';
        while ($row = mysql_fetch_assoc($query)) {
            echo '<option value="' . $row["cat_id"] . '"selected>' . $row["cat_name"] . '</option>';
        }
    } else {
        echo '<option value="">subcategory not available</option>';
    }
   
}
?>