<?php session_start();
$con = mysql_connect("localhost", "root","") or die("Unable to connect to MySQL");
$db= mysql_select_db("catalog_management") or die("unable to connect");
//print_r($_POST);

$nm=$_POST["name"];
$password=$_POST["password"];

$sel="SELECT * from login where uname='".$nm."' and password='".$password."'";
$res=mysql_query($sel);

//print_r(mysql_num_rows($res)); die;
if(mysql_num_rows($res) == 1)
{
	$row=mysql_fetch_array($res);
	$_SESSION["uid"]=$row["id"];
	$_SESSION["uname"]=$row["uname"];
	header("location:dashboard.php");
}
else
{
	//header("location:login.php");
	echo "<script>alert('Invalid Username or Password')</script>";
	echo "<script>window.location.href='login.php'</script>";
}
?>
