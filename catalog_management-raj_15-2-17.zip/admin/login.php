<?php
$con = mysql_connect("localhost", "root","") or die("Unable to connect to MySQL");
$db= mysql_select_db("catalog_management") or die("unable to connect");
?>

<center>
    <fieldset min-width:10px>
        <legend>Login Form</legend>
    <form action="process_login.php" method="POST">
			<table border= 0px>
				<tr>
					<td>
						UserId:
					</td>
					<td>
						<input type="text" name="name">
					</td>
				</tr>
				<tr>
					<td>
						Password:
					</td>
					<td>
						<input type="password" name="password">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="submit" value="login">
					</td>
				</tr>
			</table>
	</form>
    </fieldset>
</center>
