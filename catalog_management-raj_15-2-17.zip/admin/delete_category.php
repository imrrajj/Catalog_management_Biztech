<?php	session_start();

$con = mysql_connect("localhost", "root","") or die("Unable to connect to MySQL");
$db= mysql_select_db("catalog_management") or die("unable to connect");
echo "hi";
$a= $_GET['chkid'];	
mysql_query("delete FROM `categories` where id = $a");
echo "records deleted";
header("location:manage_category.php");	
?>