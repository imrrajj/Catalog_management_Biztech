

<html>
    <head>
        <title></title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <style type="text/css">
            textarea
            {
                overflow-y: scroll;
            }
            .error{
                color:red;
            }
        </style>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
        <script type="text/javascript" src="jquery.validate.min.js"></script>
        <script type="text/javascript">
            $(function () {
                $("form[name='form']").validate({
                    rules: {
                        cname: "required",
                        de: "required",
                        sde: "required",
                        status: "required",
                        image: "required"
                    },
                    messages: {
                        cname: "enter name",
                        de: "enter Description",
                        sde: "enter short Description",
                        status: "select status",
                        image: "select file"
                    }
                });
            });
        </script>
    </head>
    <body>
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <ul class="nav navbar-nav">
                    <li><a href="dashboard.php">Home</a></li>
                    <li class="active"><a href="manage_category.php">Manage Category</a></li>
                    <li><a href="manage_sub_category.php">Manage Sub-category</a></li>
                    <li><a href="manage_product.php">Manage Product</a></li>
                    <li><a href="manage_customers.php">Manage Customers</a></li>
                </ul>
            </div>
        </nav>
    </body>
</html>

<?php if (!isset($_GET['chk'])) { ?>
    <form action="" method="POST" name="form" enctype="multipart/form-data" >
        <table border=0px width="200">
            <tr>
                <td>Category Name</td>
                <td><input type="text" name="cname"></td>
            </tr>
            <tr>
                <td>Description</td>
                <td><textarea rows="5" cols="20" name="de"></textarea></td>
            </tr>
            <tr>
                <td>Short Description</td>
                <td><textarea rows="4" cols="15" name="sde"></textarea></td>
            </tr>
            <tr>
                <td>Status</td>
                <td><input type="radio" value="0" name="status">Inactive
                    <input type="radio" value="1" name="status">Active</td>
            </tr>
            <tr>
                <td>Upload Image</td>
                <td><input type='file' name='image'></td>
            </tr>
        </table>
        <input type="submit" value="ADD" name="submit" onclick="validate()">
    </form>

<?php
} else {


    $con = mysql_connect("localhost", "root", "");
    $db = mysql_select_db("catalog_management");
    $b = $_GET['chk'];
    $sql = "SELECT * FROM categories where cat_id='$b'";
    $res = mysql_query($sql);
    $row = mysql_fetch_array($res);
    ?>
    <form action="" method="POST" name="form" enctype="multipart/form-data" >
        <table border=0px>
            <tr>
                <td>Category Name</td>
                <td><input type="text" name="cname" value=" <?php echo $row['cat_name']; ?>"></td>
            </tr>
            <tr>
                <td>Description</td>
                <td><textarea rows="5" cols="50" name="de"><?php echo $row['description']; ?></textarea></td>
            </tr>
            <tr>
                <td>Short Description</td>
                <td><textarea rows="4" cols="40" name="sde"><?php echo $row['sdescription']; ?></textarea></td>
            </tr>
            <tr>
                <td>Status</td>
                <td><input type="radio" value="0" name="status" <?php echo ($row['status'] == "0") ? 'checked="checked"' : ""; ?>>Inactive
                    <input type="radio" value="1" name="status" <?php echo ($row['status'] == "1") ? 'checked="checked"' : ""; ?>>Active</td>
            </tr>
            <tr>
                <td>Upload Image</td>
                <td><input type='file' name='image'><img src='uploads/<?php echo $row['file']; ?>' width='100' height='100'></td>
            </tr>
        </table>
        <input type="submit" value="UPDATE" name="upd" >
    </form>
<?php } ?>

<?php
if (isset($_POST['submit'])) {
    $cname = $_POST['cname'];
    $de = $_POST['de'];
    $sde = $_POST['sde'];
    $status = $_POST['status'];
    $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
    //print_r($_POST); die;
    $file_loc = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_type = $_FILES['image']['type'];
    $folder = "uploads/";
    move_uploaded_file($_FILES['image']['tmp_name'], $folder . $file);

    $con = mysql_connect("localhost", "root", "") or die("Unable to connect to MySQL");
    $db = mysql_select_db("catalog_management") or die("unable to connect");

    echo $ins = "INSERT INTO `categories`( `cat_name`, `description`, `sdescription`, `status`, `file`) VALUES ('$cname','$de','$sde','$status','$file')";
//print_r($ins);die;
    mysql_query($ins);

    header("location:manage_category.php");
}
?>

<?php
if (isset($_POST['upd'])) {
    $cname = $_POST['cname'];
    $de = $_POST['de'];
    $sde = $_POST['sde'];
    //$status=$_POST['status'];
    $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
    $file_loc = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_type = $_FILES['image']['type'];
    $folder = "uploads/";
    move_uploaded_file($_FILES['image']['tmp_name'], $folder . $file);

    $con = mysql_connect("localhost", "root", "") or die("Unable to connect to MySQL");
    $db = mysql_select_db("catalog_management") or die("unable to connect");

    $upd = "UPDATE `categories` SET `cat_name`='$cname',`description`='$de',`sdescription`='$sde',`status`='$status',`file`='$file' WHERE cat_id='$b'";
//print_r($upd); die;
    mysql_query($upd);
    echo "updated";
    echo'<script>window.location="manage_category.php";</script>';
}
?>