<?php

$conn = mysqli_connect('localhost', 'root', '', 'test_db');

if (isset($_POST["country_id"]) && !empty($_POST["country_id"])) {

    $query = mysqli_query($conn, "SELECT * FROM state WHERE country_id =" . $_POST['country_id'] . " ORDER BY state_name ASC");


    $rowCount = mysqli_num_rows($query);
   
    if ($rowCount > 0) {

        echo '<option value="">Select state</option>';
        while ($row = mysqli_fetch_assoc($query)) {
            echo '<option value="' . $row['state_id'] . '">' . $row['state_name'] . '</option>';
        }
    } else {

        echo '<option value="">State not available</option>';
    }
   
}

?>