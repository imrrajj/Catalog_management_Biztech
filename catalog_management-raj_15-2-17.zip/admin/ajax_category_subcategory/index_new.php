<script src="jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#country').on('change', function () {
            var countryID = $(this).val();
            if (countryID) {
                $.ajax({
                    type: 'POST',
                    url: 'ajaxData.php',
                    data: 'country_id=' + countryID,
                    success: function (html) {
                        $('#state').html(html);
                    }
                });
            } else {
                $('#state').html('<option value="">Select country first</option>');
            }
        });
    });
</script>

Country:
<select name="country" id="country">
    <option value="">Select Country</option>
    <?php
    $conn = mysqli_connect('localhost', 'root', '', 'test_db');
    $sql = "SELECT * FROM `country` ORDER BY country_name ASC";
    $query = mysqli_query($conn, $sql);
    while ($row1 = mysqli_fetch_array($query)) {
        ?>
        <option value="<?php echo $row1[0]; ?>"><?php echo $row1[1]; ?></option>
    <?php } ?>
</select>

State:
<select name="state" id="state">
    <option value="">select state</option>
</select>