<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
    <body>
        <header>
            <nav class="navbar navbar-inverse" style="background-color: lightgrey" >
                <div class="container-fluid">
                    <div class="navbar-header">
                        <a class="navbar-brand" href="#"></a>
                    </div>
                    <ul class="nav navbar-nav">
                        <li ><a href="index.php">Home</a></li>

                        <?php
                        $con = mysql_connect("localhost", "root", "") or die("Unable to connect to MySQL");
                        $db = mysql_select_db("catalog_management") or die("unable to connect");

                        $res = mysql_query("SELECT * FROM categories where p_id='0' and status='1'");

                        while ($row = mysql_fetch_array($res)) {
                            ?>
                            <li class="dropdown">
                                <a  href="categoryview.php?id=<?php echo $row["cat_id"]; ?>" style='color:red'><?php echo $row['cat_name']; ?></a><a class="dropdown-toggle" data-toggle="dropdown"><span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                    <li><a href="product.php?pid=<?php echo $row["cat_id"]; ?>"></a></li>

                                    <?php
                                    $res1 = mysql_query("SELECT * FROM categories where  p_id =$row[cat_id]");
                                    while ($row1 = mysql_fetch_array($res1)) {
                                        ?>
                                        <li>
                                            <a><?php echo $row1['cat_name']; ?></a>
                                        </li>
                                    <?php }
                                    ?>
                                </ul>
                            </li>
                            <?php
                        }
                        ?>


                    </ul>
                </div>
            </nav>
        </header>
        <div class="row">
            <?php
            if ($_GET['id']) {
                //echo $_GET['id']; die;
                $con = mysql_connect("localhost", "root", "") or die("Unable to connect");
                $db = mysql_select_db("catalog_management") or die("Unable to connect to MySQL");
                $id = $_GET['id'];
                $sql = "SELECT * FROM `categories` where  cat_id=$id and status='1'";
                $res1 = mysql_query($sql);
                while ($row = mysql_fetch_array($res1)) {
                    ?>

                    <div class="col-md-3"></div>
                    <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-thumbnail"><img src="../admin/uploads/<?php echo "$row[file]"; ?>" class="img-responsive"></div>
                            <div class="panel-body">
                                <p class="lead"><?php echo "$row[cat_name]"; ?></p>
                                <p><?php echo "$row[description]"; ?></p>
                                <p><?php echo "$row[sdescription]"; ?></p>

                            </div>
                        </div><!--/panel--> 

                        <!--      </div>/col   -->
                    </div>



                    <?php
                }
                ?>
            </div> 


            <div class="row">
                <?php
                $con = mysql_connect("localhost", "root", "") or die("Unable to connect");
                $db = mysql_select_db("catalog_management") or die("Unable to connect to MySQL");
                $cat_id = $_GET['id'];
                $sql = "SELECT * FROM `categories` where p_id>'0' AND p_id=$cat_id AND status='1'";
                $res1 = mysql_query($sql);
                while ($row = mysql_fetch_array($res1)) {
                    ?>

                    <div class="col-md-4"><a href="product.php?pid=<?php echo $row["cat_id"]; ?>">
                            <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="../admin/uploads/<?php echo "$row[file]"; ?>" class="img-responsive"></div>
                                <div class="panel-body">
                                    <p class="lead"><?php echo "$row[cat_name]"; ?></p>
                                    <p><?php echo "$row[description]"; ?></p>
                                    <p><?php echo "$row[sdescription]"; ?></p>

                                </div>
                            </div><!--/panel--> 

                            <!--      </div>/col   -->  
                    </div>



                    <?php
                }
            }
            ?>
        </div> </a>





</body>
</html>


