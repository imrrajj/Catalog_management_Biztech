<?php
session_start();
?>

<?php include 'header.php'; ?>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" href="style.css" type="text/css"/>
        <script type="text/javascript" src="validation.js"></script>
    </head>
    <body>
        <?php
        $sql = "SELECT * FROM `address` where u_id=" . $_SESSION["uid"];
        $res = mysql_query($sql);
        $row = mysql_fetch_array($res);
        $num_rows = mysql_num_rows($res);
        echo "$num_rows";
        
        
        $fullname = $row[2];
        $exp = explode(" ", $fullname);
        //print_r($exp);
        
        ?>
        <form action="insert_cart.php" method="POST" id="frm" onsubmit="return formsubmit();">

            <!--******************************** Billing Address  *********************************** -->
<?php if($num_rows>0){ ?>
            <div class="left1" id="left1" name="left1">
                <span class="img1"></span><span class="bill">BILLING ADDRESS</span><br /><br />
                <table cellpadding="5"> 
                    <tr>
                        <td>First Name *<br /><input type="text" name="fname" id="fname" placeholder="First Name" value="<?php echo $exp[0] ?>"/><br /><label id="fnm"></label></td>
                        <td>Last Name *<br /><input type="text" name="lname" id="lname" placeholder="Last Name" value="<?php echo $exp[1] ?>"/><br /><label id="lnm"></label></td>
                    </tr>
                    <tr>
                        <td>Email Address *<br /><input type="text" name="email1" id="email1" placeholder="Email Address" value="<?php echo $row['email']; ?>" /><br /><label id="eml"></label></td>
                        <td>Telephone *<br /><input type="text" name="tel1" id="tel1" placeholder="Telephone" value="<?php echo $row['telephone']; ?>"/><br /><label id="tel" ></label></td>
                    </tr>
                    <tr>
                        <td colspan="2">Address *<br /><input type="text" name="addr1" id="addr1" size="43" placeholder="Address-1" value="<?php echo $row['address'];?>"/><br /><label id="add1"></label></td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="text" name="addr2" id="addr2" size="43" placeholder="Address-2"/></td>
                    </tr>
                    <tr>
                        <td colspan="2">Country *<br /><select name="country1" id="country1" style="width:355px;">
                                <option value="">-------------------------------Select Country-------------------------</option>
                                <option value="India" <?php if($row['country']=="India") {echo 'selected = "selected"' ;} ?>>India</option>
                                <option value="Australia" <?php if($row['country']=="Australia") {echo 'selected = "selected"' ;} ?>>Australia</option>
                                <option value="Bangladesh" <?php if($row['country']=="Bangladesh") {echo 'selected = "selected"' ;} ?>>Bangladesh</option>
                                <option value="Bhutan" <?php if($row['country']=="Bhutan") {echo 'selected = "selected"' ;} ?>>Bhutan</option>
                                <option value="Brazil" <?php if($row['country']=="Brazil") {echo 'selected = "selected"' ;} ?>>Brazil</option>
                                <option value="Brunei" <?php if($row['country']=="Brunei") {echo 'selected = "selected"' ;} ?>>Brunei</option>
                            </select><br /><label id="cou1"></label></td>
                    </tr>
                    <tr>
                        <td colspan="2">City *<br /><input type="text" name="city1" id="city1" size="43" placeholder="City" value="<?php echo $row['city']; ?>" /><br /><label id="cty"></label></td>
                    </tr>
                    <tr>
                        <td>Zip/Postal Code *<br /><input type="text" name="zip1" id="zip1" placeholder="380015" value="<?php echo $row['zip']; ?>"/><br /><label id="zip"></label></td>
                        <td>State Province *<br /><input type="text" name="state1" id="state1" placeholder="State" value="<?php echo $row['state']; ?>"/></td>
                    </tr>
                    <tr>
                        <td>Company *<br /><input type="text" name="company1" id="company1" placeholder="Company" value="<?php echo $row['company']; ?>" /></td>
                        <td>Fax *<br /><input type="text" name="fax1" id="fax1" placeholder="Fax" value="<?php echo $row['fax']; ?>"/></td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="checkbox" name="chk1" id="chk1"  value="yes" />Create an account for later use*</td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="checkbox" class="chk22" name="shipadd" id="shipadd" value="1" checked="true" onclick="showshipaddress()" checked/>Ship to the same address*</td>
                    </tr>
                </table>
            </div>
<?php } else { ?>
    
    <div class="left1" id="left1" name="left1">
                <span class="img1"></span><span class="bill">BILLING ADDRESS</span><br /><br />
                <table cellpadding="5"> 
                    <tr>
                        <td>First Name *<br /><input type="text" name="fname" id="fname" placeholder="First Name" /><br /><label id="fnm"></label></td>
                        <td>Last Name *<br /><input type="text" name="lname" id="lname" placeholder="Last Name" /><br /><label id="lnm"></label></td>
                    </tr>
                    <tr>
                        <td>Email Address *<br /><input type="text" name="email1" id="email1" placeholder="Email Address"  /><br /><label id="eml"></label></td>
                        <td>Telephone *<br /><input type="text" name="tel1" id="tel1" placeholder="Telephone" /><br /><label id="tel" ></label></td>
                    </tr>
                    <tr>
                        <td colspan="2">Address *<br /><input type="text" name="addr1" id="addr1" size="43" placeholder="Address-1"/><br /><label id="add1"></label></td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="text" name="addr2" id="addr2" size="43" placeholder="Address-2"/></td>
                    </tr>
                    <tr>
                        <td colspan="2">Country *<br /><select name="country1" id="country1" style="width:355px;">
                                <option value="">-------------------------------Select Country-------------------------</option>
                                <option value="India">India</option>
                                <option value="Australia">Australia</option>
                                <option value="Bangladesh">Bangladesh</option>
                                <option value="Bhutan">Bhutan</option>
                                <option value="Brazil">Brazil</option>
                                <option value="Brunei">Brunei</option>
                            </select><br /><label id="cou1"></label></td>
                    </tr>
                    <tr>
                        <td colspan="2">City *<br /><input type="text" name="city1" id="city1" size="43" placeholder="City" /><br /><label id="cty"></label></td>
                    </tr>
                    <tr>
                        <td>Zip/Postal Code *<br /><input type="text" name="zip1" id="zip1" placeholder="380015" /><br /><label id="zip"></label></td>
                        <td>State Province *<br /><input type="text" name="state1" id="state1" placeholder="State" /></td>
                    </tr>
                    <tr>
                        <td>Company *<br /><input type="text" name="company1" id="company1" placeholder="Company" /></td>
                        <td>Fax *<br /><input type="text" name="fax1" id="fax1" placeholder="Fax" /></td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="checkbox" name="chk1" id="chk1"  value="yes" />Create an account for later use*</td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="checkbox" class="chk22" name="shipadd" id="shipadd" value="1" checked="true" onclick="showshipaddress()" checked/>Ship to the same address*</td>
                    </tr>
                </table>
            </div>
    
<?php } ?>
                <div id="shipaddress" class="shipaddress" style="display:none;">
                    <table cellpadding="5">
                        <tr>
                            <td colspan="2"><span class="bill" style="padding-left:0px !important;">SHIPPING ADDRESS</span></td>
                        </tr>
                        <tr>
                            <td>First Name *<br /><input type="text" name="fname1" id="fname1" placeholder="First Name"/><br /><label id="fnm1"></label></td>
                            <td>Last Name *<br /><input type="text" name="lname1" id="lname1" placeholder="Last Name"/><br /><label id="lnm1"></label></td>
                        </tr>
                        <tr>
                            <td colspan="2">Telephone *<br /><input type="text" name="tel2" id="tel2" placeholder="Telephone"/><br /><label id="tel21"></label></td>
                        </tr>
                        <tr>
                            <td colspan="2">Address *<br /><input type="text" name="addr12" id="addr12" size="43" placeholder="Address-1"/><br /><label id="add21"></label></td>
                        </tr>
                        <tr>
                            <td colspan="2"><input type="text" name="addr22" id="addr22" size="43" placeholder="Address-2"/></td>
                        </tr>
                        <tr>
                            <td colspan="2">Country *<br /><select name="country2" id="country2" style="width:355px;">
                                    <option value="">-------------------------------Select Country----------------------------------------</option>
                                    <option value="India">India</option>
                                    <option value="Australia">Australia</option>
                                    <option value="Bangladesh">Bangladesh</option>
                                    <option value="Bhutan">Bhutan</option>
                                    <option value="Brazil">Brazil</option>
                                    <option value="Brunei">Brunei</option>
                                </select></td>
                        </tr>
                        <tr>
                            <td colspan="2">City *<br /><input type="text" name="city2" id="city2" size="43" placeholder="City"/></td>
                        </tr>
                        <tr>
                            <td>Zip/Postal Code *<br /><input type="text" name="zip12" id="zip12" placeholder="380015"/><br /><label id="zip21"></label></td>
                            <td>State Province *<br /><input type="text" name="state2" id="state2" placeholder="State"/></td>
                        </tr>
                        <tr>
                            <td>Company *<br /><input type="text" name="company2" id="company2" placeholder="Company"/></td>
                            <td>Fax *<br /><input type="text" name="fax2" id="fax2" placeholder="Fax"/></td>
                        </tr>
                    </table>
                </div>
            </div>

            <!--******************************** Shipping Method  *********************************** -->


            <div class="center1" id="center1" name="center1">
                <span class="img2"></span><span class="ship">SHIPPING METHOD</span><br /><br />
                <table cellpadding="5">
                    <tr>
                        <td colspan="2">Flate Rate</td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="radio" name="fix1" id="fix1" size="" value="Flat rate-fixed" />Fixed <b>₹ 500.00</b></b></td>
                    </tr>
                    <tr>
                        <td colspan="2">Express</td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="radio" name="fix1" id="fix1" size="" value="Flat rate- Express Shipping" />Express Shipping <b>₹ 1000.00</b><br /><label id="exp"></label></td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="checkbox" name="chk33" id="chk33" size="" value="yes" onclick="showmyorder()" />Add Delivery into to my order</td>
                    </tr>
                </table>
                <label id="addmyorder1"></label>
                <div id="myorder" name="myorder" class="myorder" style="display:none;">
                    <table cellpadding="5">
                        <tr>
                            <td>Delivery Date<br /><input type="date" name="d1" id="d1" placeholder="Date"/></td>
                            <td>Delivery Slot<br /><select name="dslot" id="dslot" style="width:170px;">
                                    <option value="">---Delivery Slot---</option>
                                    <option value="9-11">9-11</option>
                                    <option value="14-11">14-11</option>
                                    <option value="19-08">19-08</option>
                                    <option value="03-12">03-12</option>
                                    <option value="16-09">16-09</option>
                                    <option value="01-02">01-02</option>
                                </select></td>
                        </tr>
                        <tr>
                            <td colspan="2">Same Day Delivery Available For Orders Placed Before 11 AM.</td>
                        </tr>
                        <tr>
                            <td colspan="2">Delivery Note *<br /><textarea cols="42" rows="4" placeholder="Note" style="resize:none;"></textarea></td>
                        </tr>
                    </table>
                </div><br />
                <span class="img3"></span><span class="pay">PAYMENT METHOD</span><br /><br />
                <table cellpadding="5">
                    <tr>
                        <td colspan="2"><input type="radio" name="cash1" id="cash1" size="" value="CASH ON DELIVERY" checked="true" onclick="cashondeliveryhide()" /> &nbsp;Cash On Delivery<br /><input type="radio" name="cash1" id="cash1" size="" value="CREDIT CARD" onclick="cashondeliveryshow()" /> &nbsp;Credit Card<br /><label id="ca"></label></td>
                    </tr>
                </table>
                <div id="credit" name="credit" class="credit" style="display:none;">
                    <table cellpadding="5">
                        <tr>
                            <td colspan="2">Name Of Card *<br /><input type="text" name="nmcard" id="nmcard" size="43" placeholder="Name Of Card"/><br /><label id="ncard"></label></td>
                        </tr>
                        <tr>
                            <td colspan="2">Credit Card Type *<br /><select name="ctype" id="ctype" style="width:357px;">
                                    <option value="">---------------------Select Credit Card Type---------------------</option>
                                    <option value="American Express">American Express</option>
                                    <option value="Master Card">Master Card</option>
                                    <option value="Visa Card">Visa Card</option>
                                    <option value="Rupay Card">Rupay Card</option>
                                    <option value="Discover">Discover</option>
                                </select><br /><label id="cct"></label></td>
                        </tr>
                        <tr>
                            <td colspan="2">Credit Card Number *<br /><input type="text" name="cnum" id="cnum" size="43" placeholder="Credit Card Number"/><br /><label id="ccn"></label></td>
                        </tr>
                        <tr>
                            <td colspan="2">Expiration Date *<br />
                                <input type="date" name="day">
                                <label id="edm">
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <!--******************************** Review Your Order  *********************************** -->


            <div class="right1" id="right1" name="right1">
                <span class="img4"></span><span class="review">REVIEW YOUR ORDER</span><br /><br />
                <table cellpadding="5">
                    <tr>
                        <td style="border-bottom: 1px black solid;">Product</td>
                        <td style="border-bottom: 1px black solid;">Image</td>
                        <td style="border-bottom: 1px black solid;">Price</td>
                        <td style="border-bottom: 1px black solid;">Qty</td>
                        <td style="border-bottom: 1px black solid;">Subtotal</td>
                        <td style="border-bottom: 1px black solid;">Delete</td>
                    </tr>
                    <?php
                    $con = mysql_connect("localhost", "root", "") or die("Unable to connect");
                    $db = mysql_select_db("catalog_management") or die("Unable to connect to MySQL");

                    if (empty($_SESSION["cart"])) {
                        ?>
                        <h3 style="color:red";>cart is empty</h3> 
                        <?php
                    } else {
                        //print_r($_SESSION["cart"]);
                        $totalAll = 0;
                        foreach ($_SESSION["cart"] as $key => $value) {

                            $sql = "SELECT * FROM `product` where pr_id=" . $_SESSION['cart'][$key]['id'];
                            $res1 = mysql_query($sql);

                            $totalAll = $totalAll + ($value['qty'] * $value['price']);
                            $_SESSION['totalALL1'] = $totalAll;

                            while ($row = mysql_fetch_array($res1)) {

                                $p = $_SESSION["cart"][$key]["price"];
                                $q = $_SESSION["cart"][$key]["qty"];
                                $subtotal = $p * $q;
                                ?>
                                <tr>
                                    <td><?php echo $_SESSION["cart"][$key]["name"]; ?></td>
                                    <td><img src="../admin/uploads/<?php echo $_SESSION["cart"][$key]["file"]; ?>" width="100" height="100"></td>
                                    <td><span id="pr">₹ <?php echo number_format($_SESSION["cart"][$key]["price"], 2); ?></span></td>
                                    <td><input type="number" min="1" max="999" value='<?php echo $_SESSION["cart"][$key]["qty"]; ?>' id="qt"></td>
                                    <td><?php echo "₹" . number_format($subtotal, 2) ?></td>
                                    <td><a href="cart.php?did=<?php echo $_SESSION["cart"][$key]["id"] ?>"><img src="delete.png" width="40" height="40"></a></td> 
                                </tr>   
                                <?php
                            }
                        }
                    }
                    ?>
                    <tr>
                        <td colspan="2"><a href="index1.php" class="acoupon">Continue Shopping</a></td>
                        <td><b>Grand Total:</b></td>
                        <td><b>
                                <?php
                                if (empty($_SESSION["cart"])) {
                                    echo "-";
                                } else {
                                    echo number_format($totalAll, 2);
                                }
                                ?><b></td>
                                    </tr>
                                    <tr>
                                        <td colspan="3"></td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">Coupon Code: *<br /><input type="text" name="addrc1" id="addrc1" size="43" placeholder="Coupon Code"/></td>
                                    </tr>
                                    <tr>
                                        <td colspan="3"><input type="button" name="acoupon" id="acoupon" class="acoupon" value="Apply Coupon"/></td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">Comments <br /><textarea cols="42" rows="4" placeholder="Comments" style="resize:none;"></textarea></td>
                                    </tr>
                                    <tr>
                                        <td colspan="3"><input type="checkbox" name="chk5" id="chk5" size="" value="yes" checked/>Subscribe to our newsletter</td>
                                    </tr>
                                    <tr>
                                        <td colspan="3" align="right"><input type="submit" name="place" id="place" class="place" value="Place Order Now"/></td>
                                    </tr>
                                    </table>  
                                    </div></form></body></html>