<form action="#" method="post" class="bmain" name="bmain" id="bmain">
    First Name *<br />
    <input type="text" name="fname" id="fname" size="50" placeholder="First Name" /><br /><br />
    Last Name *<br />
    <input type="text" name="lname" id="lname" size="50" placeholder="Last Name" /><br /><br />
    Company *<br />
    <input type="text" name="company" id="company" size="50" placeholder="Company" /><br /><br />
    Email Address *<br />
    <input type="text" name="email" id="email" size="50" placeholder="Email Address" /><br /><br />
    Address *<br />
    <input type="text" name="address" id="address" size="50" placeholder="First Address" /><br /><br />
    <input type="text" name="address" id="address" size="50" placeholder="Second Address" /><br /><br />
    City *<br />
    <input type="text" name="city" id="city" size="50" placeholder="City" /><br /><br />
    State *<br />
    <select name="state" id="state" style="width:415px;height:30px;color:black;">
        <option value="">--------------------------------------Select State----------------------------------</option>
        <option value="Gujarat">Gujarat</option>
        <option value="Punjab">Punjab</option>
        <option value="Delhi">Delhi</option>
        <option value="Goa">Goa</option>
        <option value="Keral">Keral</option>
        <option value="Maharastra">Maharastra</option>
    </select><br /><br />
    Zip/Postal Code *<br />
    <input type="text" name="zip" id="zip" size="50" placeholder="Zip/Postal Code" /><br /><br />
    Country *<br />
    <select name="country" id="country" style="width:415px;height:30px;color:black;">
        <option value="">--------------------------------------Select Country----------------------------------</option>
        <option value="America">America</option>
        <option value="Algeria">Algeria</option>
        <option value="Bermuda">Bermuda</option>
        <option value="India">India</option>
        <option value="Indonesia">Indonesia</option>
        <option value="Romania">Romania</option>
    </select><br /><br />
    Telephone *<br />
    <input type="text" name="telephone" id="telephone" size="50" placeholder="Telephone" /><br /><br />
    Fax *<br />
    <input type="text" name="fax" id="fax" size="50" placeholder="Fax" /><br /><br />
    <input type="radio" name="shipadd" value="shipaddress" id="shipadd">Ship to this address<br />
    <input type="radio" name="shipadd" value="shipdiffaddress" id="shipadd">Ship to different<label id="shipadd-error" class="error" for="shipadd"></label>
    <br /><br /><input type="submit" name="sub" id="sub" value="CONTINUE"> 
</form>