<?php
session_start();
?>
<?php include 'header.php'; ?>  
<html>
    <head>
        <script type="text/javascript" src="jquery.validate.min.js"></script>
        <script type="text/javascript">
            $(function () {
                $("form[name='formm']").validate({
                    rules: {
                        qty: {
                            required: true,
                            number: true,
                            //max: 599
                        }
                    },
                    messages: {
                        qty: {
                            required: "quantity Must Be Required.",
                            number: "Only Number Allowed",
                            // max: "quantity less than 600."
                        }
                    },
                });
            });
        </script>
    </head>
    <body>
        <!--*************************products****************************-->
        <div class="row">
            <?php
            if ($_GET['pid']) {
                $con = mysql_connect("localhost", "root", "") or die("Unable to connect");
                $db = mysql_select_db("catalog_management") or die("Unable to connect to MySQL");
                // $cat_id = $_GET['pid'];
                $sql = "SELECT * FROM `product` where `pr_id`=" . $_GET['pid'];
                $res1 = mysql_query($sql);
                while ($row = mysql_fetch_array($res1)) {
                    ?>

                    <div class="col-md-4">
                        <div class="panel panel-default">
                            <form method='POST' name="formm" action="">
                                <div class="panel-thumbnail"><img src="../admin/uploads/<?php echo "$row[file]"; ?>" class="img-responsive"></div>
                                <div class="panel-body">
                                    <p class="lead"><?php echo "$row[Name]"; ?></p>
                                    <p>Price: ₹ <?php echo number_format("$row[price]", 2); ?></p>
                                    <p>Description:<?php echo "$row[Description]"; ?></p>
                                    <p>Short Description:<?php echo "$row[Short_description]"; ?></p>
                                    <p>Quantity: <input type="text" id="qty" name="qty"><?php if(isset($_SESSION["more"])){ echo $_SESSION["more"]; unset($_SESSION["more"]);} ?></p> 
                                    <p><input type='submit' style="background-color:lightblue;" value='Add to Cart' name="Submit1"></p>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!--*************************array merge for next page****************************-->
                    <?php
                    
                    if (isset($_POST['Submit1'])) {
                        $b = $_POST['qty'];
                        if ( $b > $row['Inventory']) {
                          $_SESSION["more"] = "<div class='alert alert-danger'><strong>Maximum quantity allow to purchase is $row[Inventory]</strong> </div>";
                          echo "<script>window.location='product.php?pid=$row[0]';</script>";
                          exit;
                          }

                        
                        $n = $row['Name'];
                        $p = $row['price'];
                        $f = $row['file'];
                        $d = $row['Description'];
                        $sd = $row['Short_description'];

                        $array = $_SESSION["cart"];
                        foreach ($array as $key => $value) {
                            $tmp = $array[$key]["id"];

                            $array[$key]["qty"];
                            if ($tmp == $row['pr_id']) {
                                $_SESSION["cart"][$key]["qty"] += $b;
                                echo "<script>window.location='cart.php';</script>";
                                exit;
                            }
                        }

                        if (!empty($_SESSION['cart'])) {

                            $a = array("id" => $row['pr_id'], "qty" => $b, "name" => $n, "price" => $p, "file" => $f, "desc" => $d, "sdesc" => $sd);
                            array_push($_SESSION['cart'], $a);
                        } else {

                            $_SESSION['cart'] = array();
                            $a = array("id" => $row['pr_id'], "qty" => $b, "name" => $n, "price" => $p, "file" => $f, "desc" => $d, "sdesc" => $sd);
                            array_push($_SESSION['cart'], $a);
                        }
                        ?> 
                        <script>
                            window.location.href = "cart.php";
                        </script>

                        <?php
                    }
                }
            }
            ?>

        </div> 
    </body>
</html>