//Hide Show Div Tag..

function showshipaddress()
{
    var remember = document.getElementById('shipadd');
    if (remember.checked) {
        document.getElementById("shipaddress").style.display = 'none';
    } else
    {
        document.getElementById("shipaddress").style.display = 'block';
    }
}
function showmyorder()
{
    var remember = document.getElementById('chk33');
    if (remember.checked) {
        document.getElementById("myorder").style.display = 'block';

    } else
    {
        document.getElementById("myorder").style.display = 'none';
    }
}
function cashondeliveryshow()
{
    var remember = document.getElementsByName("cash1");
    if (remember.checked) {
        document.getElementById("credit").style.display = 'none';
    }
    else
    {
        document.getElementById("credit").style.display = 'block';
    }
}
function cashondeliveryhide()
{
    var remember = document.getElementsByName("cash1");
    if (remember.checked)
    {
        document.getElementById("credit").style.display = 'none';
    } else
    {
        document.getElementById("credit").style.display = 'none';
    }
}
function formsubmit()
{
    debugger;
    var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    var email1 = document.getElementById("email1").value;
    var a = email1.indexOf("@");
    var b = email1.lastIndexOf(".");
    var tel1 = document.getElementById("tel1").value;
    var addr1 = document.getElementById("addr1").value;
    var country1 = document.getElementById("country1").value;
    var alphaExp = /^[a-zA-Z]+$/;
    var city1 = document.getElementById("city1").value;
    var zip1 = document.getElementById("zip1").value;
    var flag = 1;

//     if(day == "" || day == null)
//        {
//            document.getElementById("edm").innerHTML="This is a required field.";
//            flag=0;
//        }
//        else
//        {
//            document.getElementById("edm").innerHTML="";
//            flag=1;
//        }

    if (fname == "" || fname == null)
    {
        document.getElementById("fnm").innerHTML = "This is a required field.";
        flag = 0;
    }
    else if (fname.length < 2 || fname.length > 10)
    {
        document.getElementById("fnm").innerHTML = "Between 2 to 10 Chars.";
        flag = 0;
    }
    else if (!/^[a-zA-Z]*$/g.test(fname))
    {
        document.getElementById("fnm").innerHTML = "Only Character Allowed.";
        flag = 0;
    }
    else
    {
        document.getElementById("fnm").innerHTML = "";
        flag = 1;
    }
    if (lname == "" || lname == null)
    {
        document.getElementById("lnm").innerHTML = "This is a required field.";
        flag = 0;
    }
    else if (lname.length < 2 || lname.length > 10)
    {
        document.getElementById("lnm").innerHTML = "Between 2 to 10 Chars.";
        flag = 0;
    }
    else if (!/^[a-zA-Z]*$/g.test(lname))
    {
        document.getElementById("lnm").innerHTML = "Only Character Allowed.";
        flag = 0;
    }
    else
    {
        document.getElementById("lnm").innerHTML = "";
        flag = 1;
    }
    if (email1 == "" || email1 == null)
    {
        document.getElementById("eml").innerHTML = "This is a required field.";
        flag = 0;
    }
    else if (a < 1 || (b - a) < 2)
    {
        document.getElementById("eml").innerHTML = "Invalid.";
        flag = 0;
    }
    else
    {
        document.getElementById("eml").innerHTML = "";
        flag = 1;
    }
    if (tel1 == "" || tel1 == null)
    {
        document.getElementById("tel").innerHTML = "This is a required field.";
        flag = 0;
    }
    else if (isNaN(tel1))
    {
        document.getElementById("tel").innerHTML = "Invalid.";
        flag = 0;
    }
    else if (tel1.length < 10 || tel1.length > 10)
    {
        document.getElementById("tel").innerHTML = "Required 10 Digits.";
        flag = 0;
    }
    else
    {
        document.getElementById("tel").innerHTML = "";
        flag = 1;
    }
    if (addr1 == "" || addr1 == null)
    {
        document.getElementById("add1").innerHTML = "This is a required field.";
        flag = 0;
    }
    else
    {
        document.getElementById("add1").innerHTML = "";
        flag = 1;
    }
    if (country1 == "" || country1 == null)
    {
        document.getElementById("cou1").innerHTML = "This is a required field.";
        flag = 0;
    }
    else
    {
        document.getElementById("cou1").innerHTML = "";
        flag = 1;
    }
    if (city1 == "" || city1 == null)
    {
        document.getElementById("cty").innerHTML = "This is a required field.";
        flag = 0;
    }
    else if (!city1.match(alphaExp))
    {
        document.getElementById("cty").innerHTML = "Only Character Allowed.";
        flag = 0;
    }
    else
    {
        document.getElementById("cty").innerHTML = "";
        flag = 1;

    }
    if (zip1 == "" || zip1 == null)
    {
        document.getElementById("zip").innerHTML = "This is a required field.";
        flag = 0;
    }
    else if (isNaN(zip1))
    {
        document.getElementById("zip").innerHTML = "Invalid.";
        flag = 0;
    }
    else
    {
        document.getElementById("zip").innerHTML = "";
        flag = 1;
    }

    /************************Div Hide Show in Shipping Address************************************************************/



    /*if (  document.getElementById("chk22") != document.getElementById("chk22").checked)
     {
     //alert("bye");
     document.getElementById("shipaddress").style.display = 'block';
     }*/
    var fname1 = document.getElementById("fname1").value;
    var lname1 = document.getElementById("lname1").value;
    var tel2 = document.getElementById("tel2").value;
    var addr12 = document.getElementById("addr12").value;
    var zip12 = document.getElementById("zip12").value;

    var remember = document.getElementById('shipadd');
    if (remember.checked) {
        if (fname1 == "" || fname1 == null)
        {
            document.getElementById("fnm1").innerHTML = "This is a required field.";
            flag = 0;
        }
        else if (fname1.length < 2 || fname1.length > 10)
        {
            document.getElementById("fnm1").innerHTML = "Between 2 to 10 Chars.";
            flag = 0;
        }
        else
        {
            document.getElementById("fnm1").innerHTML = "";
            flag = 1;
        }
        if (lname1 == "" || lname1 == null)
        {
            document.getElementById("lnm1").innerHTML = "This is a required field.";
            flag = 0;
        }
        else if (lname1.length < 2 || lname1.length > 10)
        {
            document.getElementById("lnm1").innerHTML = "Between 2 to 10 Chars.";
            flag = 0;
        }
        else
        {
            document.getElementById("lnm1").innerHTML = "";
            flag = 1;
        }
        if (tel2 == "" || tel2 == null)
        {
            document.getElementById("tel21").innerHTML = "This is a required field.";
            flag = 0;
        }
        else if (isNaN(tel2))
        {
            document.getElementById("tel21").innerHTML = "Invalid.";
            flag = 0;
        }
        else
        {
            document.getElementById("tel21").innerHTML = "";
            flag = 1;
        }
        if (addr12 == "" || addr12 == null)
        {
            document.getElementById("add21").innerHTML = "This is a required field.";
            flag = 0;
        }
        else
        {
            document.getElementById("add21").innerHTML = "";
            flag = 1;
        }
        if (zip12 == "" || zip12 == null)
        {
            document.getElementById("zip21").innerHTML = "This is a required field.";
            flag = 0;
        }
        else
        {
            document.getElementById("zip21").innerHTML = "";
            flag = 1;
        }
    }

    /************************Div Hide Show in Shipping Method************************************************************/
    if ((document.getElementsByName("fix1")[0].checked == false) && (document.getElementsByName("fix1")[1].checked == false))
    {
        document.getElementById("exp").innerHTML = "This is a required field.";
        flag = 0;
    }
    else
    {
        document.getElementById("exp").innerHTML = "";
        flag = 1;
    }

    /************************Div Hide Show in Payment Method************************************************************/
    var nmcard = document.getElementById("nmcard").value;
    var ctype = document.getElementById("ctype").value;
    var cnum = document.getElementById("cnum").value;
    var remember = document.getElementsByName("cash1");

    if ((document.getElementsByName("cash1")[0].checked == false) && (document.getElementsByName("cash1")[1].checked == true))    
    {


        if ((document.getElementsByName("cash1")[0].checked == false) && (document.getElementsByName("cash1")[1].checked == false))
        {
            document.getElementById("ca").innerHTML = "This is a required field.";
            flag = 0;
        }
        else
        {
            document.getElementById("ca").innerHTML = "";
            flag = 1;
        }

        if (nmcard == "" || nmcard == null)
        {
            document.getElementById("ncard").innerHTML = "This is a required field.";
            flag = 0;
        }
        else
        {
            document.getElementById("ncard").innerHTML = "";
            flag = 1;
        }
        if (ctype == "" || ctype == null)
        {
            document.getElementById("cct").innerHTML = "This is a required field.";
            flag = 0;
        }
        else
        {
            document.getElementById("cct").innerHTML = "";
            flag = 1;
        }
        if (cnum == "" || cnum == null)
        {
            document.getElementById("ccn").innerHTML = "This is a required field.";
            flag = 0;
        }
        else if (isNaN(cnum))
        {
            document.getElementById("ccn").innerHTML = "Only Number Allowed";
            flag = 0;
        }
        else if (cnum.length < 16)
        {
            document.getElementById("ccn").innerHTML = "Required 16 Digits.";
            flag = 0;
        }
        else
        {
            document.getElementById("ccn").innerHTML = "";
            flag = 1;
        }

    }

    if (flag == 0) {
        debugger;
        return false;
    }
    else {
        debugger;
        //alert("success");
        //document.getElementById('frm').submit();
        return true;
    }


}