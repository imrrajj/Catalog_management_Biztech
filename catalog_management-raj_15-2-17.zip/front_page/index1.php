<?php session_start(); ?>
<?php include 'header.php';?>        
        <img src="electonics1.jpg"></img>
        
         <div class="navbar navbar-fixed-bottom">
            <center><p>Contact information: <a href="">someone@example.com</a>.</p></center>
        </div>
