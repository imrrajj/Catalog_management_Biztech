<?php session_start();
	unset($_SESSION["uid"]);
	unset($_SESSION["user_name"]);
	session_destroy();
	header("location:login_user.php");
?>