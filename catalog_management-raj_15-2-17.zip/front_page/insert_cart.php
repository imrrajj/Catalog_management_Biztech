<?php
session_start();
?>
<?php
require 'header.php';
?>

<!--*************************insert query in cart****************************-->
<?php
if (isset($_POST['place'])) {

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email1 = $_POST['email1'];
    $tel1 = $_POST['tel1'];
    //$addr;
    $addr1 = $_POST['addr1'];
    $addr2 = $_POST['addr2'];
    $country1 = $_POST['country1'];
    $city1 = $_POST['city1'];
    $zip1 = $_POST['zip1'];
    $state1 = $_POST['state1'];
    $company1 = $_POST['company1'];
    $fax1 = $_POST['fax1'];
    $nmcard = $_POST['nmcard'];
    $ctype = $_POST['ctype'];
    $cnum = $_POST['cnum'];
    $day = $_POST['day'];
    $fix1 = $_POST['fix1'];
    $cash1 = $_POST['cash1']; 
    
    $fname1 = $_POST['fname1'];
    $lname1 = $_POST['lname1'];
    $tel2 = $_POST['tel2'];
    //$addr;
    $addr12 = $_POST['addr12'];
    $addr22 = $_POST['addr22'];
    $country2 = $_POST['country2'];
    $city2 = $_POST['city2'];
    $zip12 = $_POST['zip12'];
    $state2 = $_POST['state2'];
    $company2 = $_POST['company2'];
    $fax2 = $_POST['fax2'];
    
    
    

    //$inventory=$_POST['inventory'];
    $order_id = rand(10, 10000000000);
    //print_r($inventory);
//**********************storing in session**************************************************

    $_SESSION['fname1'] = $fname . ' ' . $lname;
    $_SESSION['order_id1'] = $order_id;
    $_SESSION['day1'] = $day;
    $_SESSION['addr1'] = $addr1 . ',' . $addr2;
    $_SESSION['country1'] = $country1;
    $_SESSION['tel1'] = $tel1;
    $_SESSION['city1'] = $city1;
    $_SESSION['zip1'] = $zip1;
    //$_SESSION["uid"] = $uid;
   //echo $_SESSION["uid"]; exit;
//*************************************insert the form data*******************************************************
    $con = mysql_connect("localhost", "root", "") or die("Unable to connect to MySQL");
    $db = mysql_select_db("catalog_management") or die("unable to connect");

    if ($cash1 == "yes") {

        $sql = "INSERT INTO `review_order` (`order_id`,`fullname`, `email`, `telephone`, `address`, `country`, `city`, `zip`, `state`, `company`, `fax`,`card_name`, `card_type`, `card_num`, `exp_date`,`shipping_method`,`payment_method`,`status`,`u_id`) VALUES ('$order_id','$fname $lname','$email1','$tel1','$addr1 $addr2','$country1','$city1','$zip1','$state1','$company1','$fax1',0,0,0,0,'$fix1','$cash1','','".$_SESSION["uid"]."')";
        mysql_query($sql);
    } else {
        $sql = "INSERT INTO `review_order` (`order_id`,`fullname`, `email`, `telephone`, `address`, `country`, `city`, `zip`, `state`, `company`, `fax`, `card_name`, `card_type`, `card_num`, `exp_date`,`shipping_method`,`payment_method`,`status`,`u_id`) VALUES ('$order_id','$fname $lname','$email1','$tel1','$addr1 $addr2','$country1','$city1','$zip1','$state1','$company1','$fax1','$nmcard','$ctype','$cnum','$day','$fix1','$cash1','','".$_SESSION["uid"]."')";
        mysql_query($sql);
    }
//****************************************insert values into address*****************************************************************
    $sql1="INSERT INTO `address` (`u_id`, `fullname`, `email`, `telephone`, `address`, `country`, `city`, `zip`, `state`, `company`, `fax`) VALUES ('".$_SESSION["uid"]."','$fname $lname','$email1','$tel1','$addr1 $addr2','$country1','$city1','$zip1','$state1','$company1','$fax1')";
    mysql_query($sql1);

    
//*****************************to print shipping address**********************************************************************    
    if (isset($_POST['shipadd'])) {
        echo "";
    } else {
        $sql= "INSERT INTO `review_order` (`order_id`,`fullname`, `telephone`, `address`, `country`, `city`, `zip`, `state`, `company`, `fax`,`card_name`, `card_type`, `card_num`, `exp_date`,`shipping_method`,`payment_method`,`status`) VALUES ('$order_id','$fname1 $lname1','$tel2','$addr12 $addr22','$country2','$city2','$zip12','$state2','$company2','$fax2',0,0,0,0,'$fix1','$cash1','1')";
        mysql_query($sql);
        
    }
    
//******************************store the session value(cart) in the database*****************************************
    foreach ($_SESSION["cart"] as $key => $value) {
        ?>
        <?php
        $file = $_SESSION["cart"][$key]["file"];
        $p = $_SESSION["cart"][$key]["price"];
        $q = $_SESSION["cart"][$key]["qty"];
        $subtot = $p * $q;
        $product_name = $_SESSION["cart"][$key]["name"];
        ?>
        <?php
        $price = $_SESSION["cart"][$key]["price"];
        $qty = $_SESSION["cart"][$key]["qty"];
        $sql1 = "INSERT INTO `review_order_product`(`product_name`,`image`, `price`, `quantity`, `subtotal`,`order_id`) VALUES ('$product_name','$file','$price','$qty','$subtot','$order_id')";
        mysql_query($sql1);
    }
    
//**********************************update the inventory***************************************************    
    $res3 = mysql_query("SELECT Inventory FROM `product` where Name = '$product_name' ");
    while ($row3 = mysql_fetch_array($res3)) {
        $i = $row3["Inventory"];

        $finv = $i - $qty;
        $res4 = mysql_query("UPDATE `product` SET `Inventory`= $finv WHERE Name = '$product_name'");
        //print_r($res4);
    }
}
?>
<div>
    <h2 align="center">YOUR ORDER HAS BEEN RECEIVED</h2>
    <h2 align="center">THANK YOU FOR YOUR PURCHASE</h2>
    <h4 align="center">Your order id is: <?php echo $order_id; ?></h4>
    <h4 align="center">You will receive an order confirmation email with details of your order and a link to track its progress</h4>
    <span style="margin-left: 550;"><button style="background-color:lightblue;"><a href="index1.php" class="acoupon">Continue Shopping</a></button></span>
    <span><button style="background-color:lightblue;"><a href="view_order_details.php?void=<?php echo $order_id; ?>" class="acoupon">View Your Order</a></button></span>
</div>