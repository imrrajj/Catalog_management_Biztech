<?php include 'header.php'; ?>
<!--*************************categories**************************************************************************-->
<div class="row">
    <?php
    if ($_GET['id']) {
        //echo $_GET['id']; die;
        $con = mysql_connect("localhost", "root", "") or die("Unable to connect");
        $db = mysql_select_db("catalog_management") or die("Unable to connect to MySQL");
        // $pr_id=$_POST['pr_id'];
        $id = $_GET['id'];
        $sql = "SELECT * FROM `categories` where  cat_id=$id and status='1'";
        $res1 = mysql_query($sql);
        while ($row = mysql_fetch_array($res1)) {
            ?>

            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="panel panel-default">
                    <div class="panel-thumbnail"><img src="../admin/uploads/<?php echo "$row[file]"; ?>" class="img-responsive"></div>
                    <div class="panel-body">
                        <p class="lead"><?php echo "$row[cat_name]"; ?></p>
                        <p><?php echo "$row[description]"; ?></p>
                        <p><?php echo "$row[sdescription]"; ?></p>

                    </div>
                </div>

                <?php
            }
            ?>
        </div> 
<!--******************************subcategory and no of products table**********************************************-->
        <?php
        $con = mysql_connect("localhost", "root", "") or die("Unable to connect to MySQL");
        $db = mysql_select_db("catalog_management") or die("unable to connect");
        $cat_id = $_GET['id'];
        $sql1 = "SELECT * FROM `categories` where p_id=$cat_id AND status='1' group by cat_id";
        $res1 = mysql_query($sql1);
        ?>

        <div class="container">
            <div class="table-responsive">          
                <table class="table">
                    <thead>
                        <tr>
                            <th>Items</th>
                            <th>Products</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while ($row1 = mysql_fetch_array($res1)) {
                            $q=mysql_fetch_array(mysql_query("SELECT count(*) FROM `product` WHERE `sub_category`=$row1[0]"));
                            ?>
                            <tr>
                                <td><?php echo "$row1[cat_name]"; ?></td>
                                <td><?php echo $q[0] ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!--*************************sub-categories****************************-->
    <div class="row">
        <?php
        $con = mysql_connect("localhost", "root", "") or die("Unable to connect");
        $db = mysql_select_db("catalog_management") or die("Unable to connect to MySQL");
        $cat_id = $_GET['id'];
        $sql = "SELECT * FROM `categories` where p_id>'0' AND p_id=$cat_id AND status='1'";
        $res1 = mysql_query($sql);



        while ($row = mysql_fetch_array($res1)) {
            ?>

            <div class="col-md-4">
                <a href="product1.php?pid=<?php echo $row["cat_id"]; ?>">
                    <div class="panel panel-default">
                        <div class="panel-thumbnail"><img src="../admin/uploads/<?php echo "$row[file]"; ?>" class="img-responsive"></div>
                        <div class="panel-body">
                            <p class="lead"><?php echo "$row[cat_name]"; ?></p>
                            <p><?php echo "$row[description]"; ?></p>
                            <p><?php echo "$row[sdescription]"; ?></p>

                        </div>
                    </div>
                </a>
            </div>
            <?php
        }
    }
    ?>
</div> </a>
</body>
</html>


