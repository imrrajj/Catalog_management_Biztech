<?php
session_start();
?>

<?php include 'header.php'; ?>



<div align="center">
    

    <?php
    if (isset($_GET['void'])) {
        $res = mysql_query("SELECT * FROM `review_order` WHERE order_id=" . $_GET['void']);
        $res1 = mysql_query("SELECT * FROM `review_order` WHERE status='1' AND order_id=" . $_GET['void']);
        unset($_SESSION['cart']);
        $row = mysql_fetch_array($res);
        $row1 = mysql_fetch_array($res1);

        //print_r($row);
        ?>
    <h3>ORDER #<?php echo $row['order_id']; ?> -PENDING</h3>
    ORDER DATE: <?php echo date("d/m/Y"); ?> <br><br>
        <!--*************************orders****************************-->
        
        <fieldset> 
            <legend>order</legend>
            <div class="container container-fluid">
            <table class="table table-striped">
                <tr cellspacing="5" cellpadding="5">
                    <td>About this order</td>
                    <td><b>Order Information</b></td>
                </tr>
                <tr>
                    <td><b>BILLING ADDRESS</b></td>
                    <td><?php echo $row['fullname']; ?> <br>
                        <?php echo $row['address']; ?><br>
                        <?php echo $row['city']; ?><br>
                        <?php echo $row['country']; ?><br>
                        <?php echo $row['telephone']; ?><br>
                        <?php echo $row['zip']; ?>
                    </td>
                </tr>
                <tr>
                    <td><b>SHIPPING ADDRESS</b></td>
                    <?php
                    if ($row1['status'] == 0) {?>
                         <td>
                        <?php echo $row['fullname']; ?> <br>
                        <?php echo $row['address']; ?><br>
                        <?php echo $row['city']; ?><br>
                        <?php echo $row['country']; ?><br>
                        <?php echo $row['telephone']; ?><br>
                        <?php echo $row['zip']; ?>
                    </td>
                    
                        <td><?php echo $row1['fullname']; ?> <br>
                            <?php echo $row1['address']; ?><br>
                            <?php echo $row1['city']; ?><br>
                            <?php echo $row1['country']; ?><br>
                            <?php echo $row1['telephone']; ?><br>
                            <?php echo $row1['zip']; ?>
                        </td>
                    <?php } ?>
                </tr>
                <tr>
                    <th>SHIPPING METHOD</th>
                    <td><?php echo $row['shipping_method']; ?></td>
                </tr>
                <tr>
                    <th>PAYMENT METHOD</th>
                    <td><?php echo $row['payment_method']; ?></td>
                </tr>
            </table>
                </div>
        </fieldset>
        <br><br><br>
        <!--*************************items ordered****************************-->
            <div class="container container-fluid">
        <fieldset><legend>ITEMS ORDERED</legend>
            <table class="table table-striped">

                <tr>
                    <td>PRODUCT</td>
                    <td>SKU</td>
                    <td>PRICE</td>
                    <td>QTY</td>
                    <td>SUBTOTAL</td>
                </tr>

                <?php
                if (isset($_GET['void'])) {
                    //print_r($_GET); die;
                    $res1 = mysql_query("SELECT * FROM `review_order_product` where order_id=" . $_GET['void']);


                    $res2 = mysql_query("SELECT * FROM `review_order` where order_id=" . $_GET['void']);
                    $row2 = mysql_fetch_array($res2);




                    //print_r($row2); 
                    ?>
                    <?php
                    while ($row1 = mysql_fetch_array($res1)) {
                        ?>
                        <tr>
                            <td width="500"><?php echo $row1['product_name']; ?></td>
                            <td>mj0xl</td>
                            <td><?php echo $row1['price']; $tmpprice[]=$row1['subtotal']; ?></td>
                            <td>ordered:<b><?php echo $row1['quantity']; ?></b></td>
                            <td>₹ <?php echo number_format($row1['subtotal'], 2); ?></td>
                        </tr>
                         <tr>
                    <td align="right" colspan="4"><b>Subtotal:</b></td>
                    <td>₹ <?php echo number_format($row1['subtotal'], 2); ?></td>
                </tr>
                        <?php
                    }
                }
                ?>
               
                <tr>
                    <td align="right" colspan="4"><b>Shipping and Handling:</b></td>
                    <td><?php
                        if ($row2['shipping_method'] == "Flat rate-fixed") {
                            echo "₹ ".$a = "500.00";
                        } else {
                            echo "₹ ". $a = "1000.00";
                        }
                        ?></td>
                </tr>
                <tr>
                    <td align="right" colspan="4"><b>Grand Total:</b></td>
                    <td>₹ <?php
                    
                    $totalprice=array_sum($tmpprice)+$a;
                    echo number_format($totalprice, 2); ?></td>
                </tr>
                
            </table>
            <a href="view_order.php?oid=<?php echo $row['order_id']; ?>">« Back to My Orders</a>
        </fieldset>
                </div>
    <?php } ?>
</div>

</body>
</html>
