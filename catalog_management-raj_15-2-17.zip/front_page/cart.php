<?php
session_start();
//error_reporting(0);
?>
<?php include 'header.php'; ?>

<!--******************************Display the cart**********************************************-->
<div class="container container-fluid">
    <table border=1px class="table table-striped">
        <?php if (isset($_SESSION["more"])) {
            echo $_SESSION["more"];
            unset($_SESSION["more"]);
        } ?>
        <h2>Cart</h2>
        <tr>
            <th>PRODUCT</th>
            <th>Image</th>
            <th>PRICE</th>
            <th>QTY</th>
            <th>SUBTOTAL</th>
            <th>Delete</th>
        </tr>
        <?php
        $con = mysql_connect("localhost", "root", "") or die("Unable to connect");
        $db = mysql_select_db("catalog_management") or die("Unable to connect to MySQL");



        if (empty($_SESSION["cart"])) {
            ?>
            <h3 style="color:red";><b>cart is empty</b></h3>
            <?php
        } else {

            //print_r($_SESSION["cart"]);
            foreach ($_SESSION["cart"] as $key => $value) {

                $sql = "SELECT * FROM `product` where pr_id=" . $_SESSION['cart'][$key]['id'];
                $res1 = mysql_fetch_array(mysql_query($sql));
                $tmpinv = $res1['Inventory'];
                $p = $_SESSION["cart"][$key]["price"];
                $q = $_SESSION["cart"][$key]["qty"];
                $id123 = $_SESSION["cart"][$key]["id"];
                ?>
                <tr>
                <form method="post" action="">
                    <td><?php echo $_SESSION["cart"][$key]["name"]; ?></td>
                    <input type="hidden" name="hiddenid" value="<?php echo $id123; ?>">
                    <td><img src="../admin/uploads/<?php echo $_SESSION["cart"][$key]["file"]; ?>" width="100" height="100"></td>
                    <td><span id="pr">₹ <?php echo number_format($_SESSION["cart"][$key]["price"], 2); ?></span></td>
                    <td><input type="text" min="1"  size="2"  name="qty" value='<?php echo $_SESSION["cart"][$key]["qty"]; ?>' id="qt">

                        <button class="btn btn-primary" type="submit" name="update">UPDATE</button></td>
                    <td><?php echo "₹ " . number_format($p * $q, 2) ?></td>
        <?php // print_r($_SESSION['cart']);    ?>
                    <td><a href="cart.php?did=<?php echo $key; ?>"><img src="delete.png" width="40" height="40"></a></td> 
                </form>
                </tr>   
            <?php } ?>
<!--******************************onclick update event*******************************************************************-->
            <?php
            if (isset($_REQUEST['update'])) {
                
                echo $b = $_POST['qty'];
                if ($b > $tmpinv) {
                    $_SESSION["more"] = "<div class='alert alert-danger'><strong>Maximum quantity allow to purchase is $tmpinv</strong> </div>";
                    echo "<script>window.location='cart.php';</script>";
                    exit;
                }
                $hiddenid = $_POST['hiddenid'];
                $array = $_SESSION["cart"];
                foreach ($array as $key => $value) {
                    $tmp = $array[$key]["id"];
                    $array[$key]["qty"];
                    if ($tmp == $hiddenid) {
                        $_SESSION["cart"][$key]["qty"] = $b;
                        echo "<script>window.location='cart.php';</script>";
                    }
                }
            }
//    ****************************************Delete the items***********************************************************
            if (isset($_GET['did'])) {
                $did = $_GET['did'];
                unset($_SESSION["cart"][$did]);
                echo '<script>window.location="cart.php";</script>';
            }
        }
        ?>

    </table>
    <button style="background-color:lightblue;"><a href="index1.php">Continue Shopping</a></button> <br><br>
    <button style="background-color:lightgreen;"><a href="checkout.php">Proceed to Checkout</a></button>

</div>
<br>
</body>
</html>