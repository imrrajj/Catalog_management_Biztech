
<html lang="en">
    <head>
        <title></title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="validation.js" type="text/javascript"></script>

    </head>
    <body>
        <header>
            <nav class="navbar navbar-inverse" style="background-color: lightgrey" >
                <div class="container-fluid">
                    <div class="navbar-header">
                        <a class="navbar-brand" href="#"></a>
                    </div>
                    <ul class="nav navbar-nav">
                        <li ><a href="index1.php" style="color:black">Home</a></li>

                        <?php
                        $con = mysql_connect("localhost", "root", "") or die("Unable to connect to MySQL");
                        $db = mysql_select_db("catalog_management") or die("unable to connect");

                        $res = mysql_query("SELECT * FROM categories where p_id='0' and status='1'");

                        while ($row = mysql_fetch_array($res)) {
                            ?>
                            <li class="dropdown">
                                <a  href="categoryview.php?id=<?php echo $row["cat_id"]; ?>" style='color:red'><?php echo $row['cat_name']; ?></a><a class="dropdown-toggle" data-toggle="dropdown"><span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                    <li><a href="product.php?pid=<?php echo $row["cat_id"]; ?>"></a></li>

                                    <?php
                                    $res1 = mysql_query("SELECT * FROM categories where  p_id =$row[cat_id]");
                                    while ($row1 = mysql_fetch_array($res1)) {
                                        ?>
                                        <li>
                                            <a><?php echo $row1['cat_name']; ?></a>
                                        </li>
                                    <?php }
                                    ?>
                                </ul>
                            </li>

                            <?php
                        }
                        
                        
                        ?>
                        <li>
                            <a href="cart.php" style="color:black">cart
                                <span class="glyphicon glyphicon-shopping-cart"></span>
                            </a>
                        </li>
                        <li><a href="view_order.php" style="color:black">view orders</a></li>
                        <li><a href="logout_user.php" style='color:black'>Logout</a></li>

                    </ul>
                </div>
            </nav>
        </header>

        <!--        <div class="navbar navbar-fixed-bottom">
                    <center><p>Contact information: <a href="">someone@example.com</a>.</p></center>
                </div>-->

    <body>
</html>