function validate()
{

    var name = document.getElementById("name").value;
    var emails = document.getElementById("emails").value;
    var atpos = emails.indexOf("@");
    var dotpos = emails.lastIndexOf(".");
    var details = document.getElementById("details").value;
    var password = document.getElementById("password").value;
    var conpassword = document.getElementById("conpassword").value;
    var age = document.getElementById("age").value;
    var date = document.getElementById("date").value;
    var month = document.getElementById("month").value;
    var year = document.getElementById("year").value; //selectedIndex
    var check = document.getElementById("check");

    //Date Month Year Validation
    if (parseInt(year) % 4 == 0)
    {
        if (parseInt(month) == 2)
        {
            if (date > 29)
            {
                document.getElementById("mt").innerHTML = "Birthdate is Invalid.";
                //return false;
            }
        }
        if (parseInt(month) == 4 || parseInt(month) == 6 || parseInt(month) == 9 || parseInt(month) == 11)
        {
            //alert("Hi");
            if (parseInt(date) > 30)
            {
                document.getElementById("mt").innerHTML = "Birthdate is Invalid.";
                //return false;
            }
        }
        if (parseInt(month) == 1 || parseInt(month) == 3 || parseInt(month) == 5 || parseInt(month) == 7 || parseInt(month) == 8 || parseInt(month) == 10 || parseInt(month) == 12)
        {
            //alert("Hi");
            if (parseInt(date) > 31)
            {
                document.getElementById("mt").innerHTML = "Birthdate is Invalid.";
                //return false;
            }
        }
    }
    if (parseInt(year) % 4 != 0)
    {
        if (parseInt(month) == 2)
        {
            if (date > 28)
            {
                document.getElementById("mt").innerHTML = "Birthdate is Invalid.";
                //return false;
            }
        }
        if (parseInt(month) == 4 || parseInt(month) == 6 || parseInt(month) == 9 || parseInt(month) == 11)
        {
            //alert("Hi");
            if (parseInt(date) > 30)
            {
                document.getElementById("mt").innerHTML = "Birthdate is Invalid.";
                //return false;
            }
        }
        if (parseInt(month) == 1 || parseInt(month) == 3 || parseInt(month) == 5 || parseInt(month) == 7 || parseInt(month) == 8 || parseInt(month) == 10 || parseInt(month) == 12)
        {
            //alert("Hi");
            if (parseInt(date) > 31)
            {
                document.getElementById("mt").innerHTML = "Birthdate is Invalid.";
                //return false;
            }
        }
    }
    //Required Field Validation
    if (name == "")
    {
        //alert("Hello");
        document.getElementById("nm").innerHTML = "Name Must Be Required.";
        document.getElementById("name").focus();
        count = 0;
    }
    else if (!isNaN(name))
    {
        document.getElementById("nm").innerHTML = "Only Character Allow.";
        document.getElementById("name").focus();

        count = 0;
        //count++;
    }
    else if (name.length < 2 || name.length > 10)
    {
        document.getElementById("nm").innerHTML = "Name Between 2 to 10 characters.";
        document.getElementById("name").focus();
        count=0;
        //count++;
    }
    else
    {
        document.getElementById("nm").innerHTML = "";
        //document.getElementById("nm").style.display="none";
    }
    if (emails == "")
    {
        document.getElementById("em").innerHTML = "Email Must Be Required.";
        count=0;
        //count++;

    }
    else if (atpos < 1 || (dotpos - atpos < 2))
    {
        document.getElementById("em").innerHTML = "Email is Invalid.";
        count=0;
        //count++;
    }
    else
    {
        document.getElementById("em").innerHTML = "";
    }
    if (details == "")
    {
        document.getElementById("dt").innerHTML = "Details Must Be Required.";
        count=0;
        // count++;
    }
    else
    {
        document.getElementById("dt").innerHTML = "";
    }
    if (password == "")
    {
        document.getElementById("pwd").innerHTML = "Password Must Be Required.";
        count=0;
        //count++;
    }
    else if (password.length < 2 || password.length > 10)
    {
        document.getElementById("pwd").innerHTML = "Password Between 2 to 10 characters.";
        count=0;
        //count++;
    }
    else
    {
        document.getElementById("pwd").innerHTML = "";
    }
    if (conpassword == "")
    {
        document.getElementById("cpwd").innerHTML = "Confirm Password Must Be Required.";
        count=0;
        //count++;
    }
    else if (password != conpassword)
    {
        document.getElementById("cpwd").innerHTML = "Password Mismatch.";
        count=0;
        //count++;
    }
    else
    {
        document.getElementById("cpwd").innerHTML = "";
    }
    if (age == "")
    {
        document.getElementById("ag").innerHTML = "Age Must Be Required.";
        count=0;
        //count++;
    }
    else if (isNaN(age))
    {
        document.getElementById("ag").innerHTML = "Age Must Be Numeric.";
        count=0;
        //count++;
    }
    else if (age.length > 2)
    {
        document.getElementById("ag").innerHTML = "Age Must Be less 100.";
        count=0;
        //count++;
    }
    else
    {
        document.getElementById("ag").innerHTML = "";
    }
    if (date == "" || date == null)
    {
        document.getElementById("dte").innerHTML = "Date Not Selected.";
        count=0;
        //count++;
    }
    else
    {
        document.getElementById("dte").innerHTML = "";
    }
    if (month == "" || month == null)
    {
        document.getElementById("monthss").innerHTML = "Month Not Selected.";
        count=0;
        //count++;
    }
    else
    {
        document.getElementById("monthss").innerHTML = "";
    }

    if (year == "" || year == null)
    {
        document.getElementById("yr").innerHTML = "Year Not Selected.";
        count=0;
        //count++;
    }
    else
    {
        document.getElementById("yr").innerHTML = "";
    }
    if ((document.getElementsByName("gender")[0].checked == false) && (document.getElementsByName("gender")[1].checked == false))
    {
        document.getElementById("gen").innerHTML = "Gender Not Selected.";
        count=0;
        //count++;
    }
    else
    {
        document.getElementById("gen").innerHTML = "";
    }
    if (check != check.checked)
    {
        document.getElementById("chk").innerHTML = "TOS are not Checked."
        count=0;
        //count++;
    }
    
    
    if (check = check.checked)
    {
        document.getElementById("chk").innerHTML = "";
        return true;
    }

    if (count == 0)
    {
        return false;
    }
    else
    {
        return true;
    }

    //window.location.href="login_user.php";
}