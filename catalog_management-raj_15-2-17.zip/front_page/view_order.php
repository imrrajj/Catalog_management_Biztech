<?php
session_start();
$con = mysql_connect("localhost", "root", "") or die("Unable to connect to MySQL");
$db = mysql_select_db("catalog_management") or die("unable to connect");
?>
<?php include 'header.php'; ?>


>
    <?php
//    **********************************fetch the data from database********************************************************

    //echo $_SESSION["uid"];
    //echo $_GET['userid'];
//       $res5=  mysql_query("");
//       $row5=  mysql_fetch_array($res5);

//    if (isset($_GET['oid'])) {
//
//        $res1 = mysql_query("SELECT * FROM review_order where order_id=" . $_GET['oid']);
//        $row = mysql_fetch_array($res1);
//
//        $res2 = mysql_query("SELECT * FROM `review_order_product` WHERE order_id=" . $_GET['oid']);
//        $row1 = mysql_fetch_array($res2);
        //print_r($r); die;
        //print_r($db); die;


        $res3 = mysql_query("SELECT * FROM review_order join review_order_product on review_order.order_id=review_order_product.order_id and review_order.u_id=" . $_SESSION['uid']);
        
        //$res3 = mysql_query("SELECT * FROM review_order_product where u_id=" . $_SESSION['uid']);
        
        

        //print_r($row);
        ?>
<div width='500' align='center'>
    <h1 align='center'>MY ORDERS</h1>
    <p align='center'><b>Hello,<?php echo ucfirst($_SESSION['uname']); ?> !</b></p>  
    <p align='center'>From your My Account Dashboard you have the ability to view a snapshot of your recent account activity and update your account information. Select a link below to view or edit information.
    </p>
    <h3>RECENT ORDERS</h3>
    <div class="container container-fluid">
        <table class="table table-striped">
            <tr>
                <th>ORDER #</th>
                <th>DATE</th>
                <th>SHIP TO</th>
                <th>ORDER TOTAL</th>
                <th>STATUS</th>
                <th></th>
            </tr>

            
                <?php
                while ($row2 = mysql_fetch_array($res3)) {
                    ?>
            <tr>
                    <td><?php echo $row2['order_id']; ?></td>
                    <td><?php echo date("d/m/Y"); ?></td>
                    <td><?php echo $row2['fullname']; ?></td>
                    <td><?php echo "₹ " . number_format($row2['subtotal'], 2); ?></td>

                    <td>pending</td>
                    <td><a href="view_order_details.php?void=<?php echo $row2['order_id']; ?>">View Order Details >></a></td>
        </tr>
                        <?php }
    ?>
            

        </table>
        </div>
<?php // } ?>
</div>