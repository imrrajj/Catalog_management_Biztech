<?php include 'header.php'?>
<!--*************************sub-categories****************************-->
<div class="row">
    <?php
    $con = mysql_connect("localhost", "root", "") or die("Unable to connect");
    $db = mysql_select_db("catalog_management") or die("Unable to connect to MySQL");

    if (isset($_GET['pid'])) {
        //echo $id = $_GET['pid'];
        $cat_id = $_GET['pid'];
        $sql = "SELECT * FROM `categories` where p_id>'0' AND cat_id= '" . $cat_id . "' AND status='1'";
        $res1 = mysql_query($sql);

        while ($row = mysql_fetch_array($res1)) {
            ?>

            <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-thumbnail"><img src="../admin/uploads/<?php echo "$row[file]"; ?>" class="img-responsive"></div>
                        <div class="panel-body">
                            <p class="lead"><?php echo "$row[cat_name]"; ?></p>
                            <p><?php echo "$row[description]"; ?></p>
                            <p><?php echo "$row[sdescription]"; ?></p>

                        </div>
                    </div>  
            </div>
            <?php
        }
    }
    ?>
</div> </a>
<!--*************************product****************************-->
<div class="row">
    <?php
    if ($_GET['pid']) {
        $con = mysql_connect("localhost", "root", "") or die("Unable to connect");
        $db = mysql_select_db("catalog_management") or die("Unable to connect to MySQL");
        // $cat_id = $_GET['pid'];
        $sql = "SELECT * FROM `product` where sub_category=" . $_GET['pid'];
        $res1 = mysql_query($sql);
        while ($row = mysql_fetch_array($res1)) {
            ?>

            <div class="col-md-4">
                <div class="panel panel-default"> <a href="product.php?pid=<?php echo $row[0];?>">
                    <form method='POST'>
                        <div class="panel-thumbnail"><img src="../admin/uploads/<?php echo "$row[file]"; ?>" class="img-responsive"></div>
                        <div class="panel-body">
                            <p class="lead"><?php echo "$row[Name]"; ?></p>
                            <p><?php echo "$row[Description]"; ?></p>
                            <p><?php echo "$row[Short_description]"; ?></p>

                        </div>
                    </form></a>
                </div>
            </div>

            <?php
        }
    }
    ?>

</div>        


