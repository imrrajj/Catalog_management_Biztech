
<?php
if ($_GET['chk']) {
    $con = mysql_connect("localhost", "root", "") or die("Unable to connect to MySQL");
    $db = mysql_select_db("catalog_management") or die("unable to connect");
    $cat_id = $_GET['chk'];
    $q = mysql_query("SELECT * FROM `categories` where p_id>'0' AND p_id=$cat_id");
    ?>
    <?php
    while ($row = mysql_fetch_array($q)) {
        ?>
        <table border="2" id="table1">
            <tr>
                <td>
                    <img src="uploads/<?php echo "$row[file]";?>" height="100px" width="100px">
                </td>
               
            </tr>
            <tr>
                <td>
                    <a href="product.php?chk1=<?php echo "$row[cat_id]"; ?> "><?php echo "$row[cat_name]"; ?></a>
                </td>
            </tr>  
            <tr>
                <td>
                    <?php echo "$row[description]"; ?>
                </td>
            </tr>             
        </table>
        <?php
    }
}
?>