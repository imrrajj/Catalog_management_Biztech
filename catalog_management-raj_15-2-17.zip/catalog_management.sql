-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 15, 2017 at 11:59 AM
-- Server version: 5.6.33-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `catalog_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE IF NOT EXISTS `address` (
  `addr_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telephone` int(11) NOT NULL,
  `address` varchar(100) NOT NULL,
  `country` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `zip` int(11) NOT NULL,
  `state` varchar(20) NOT NULL,
  `company` varchar(20) NOT NULL,
  `fax` int(11) NOT NULL,
  PRIMARY KEY (`addr_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`addr_id`, `u_id`, `fullname`, `email`, `telephone`, `address`, `country`, `city`, `zip`, `state`, `company`, `fax`) VALUES
(2, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(3, 1, 'Meet Shah', 'meet@gmail.com', 2147483647, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(4, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(5, 1, 'Meet Shah', 'meet@gmail.com', 2147483647, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(6, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(7, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(8, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(9, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(10, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(11, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(12, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(13, 0, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(14, 0, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(15, 0, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(16, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(17, 2, 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548),
(18, 2, 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548),
(19, 2, 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548),
(20, 2, 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548),
(21, 2, 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548),
(22, 2, 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548),
(23, 2, 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548),
(24, 2, 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548),
(25, 2, 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548),
(26, 2, 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548),
(27, 2, 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548),
(28, 2, 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548),
(29, 2, 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548),
(30, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(31, 2, 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548),
(32, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(33, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(34, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(35, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(36, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(37, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(38, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(39, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(40, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(41, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(42, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(43, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(44, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(45, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(46, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(47, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(48, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(49, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(50, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(51, 1, 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985),
(52, 2, 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(20) NOT NULL,
  `description` varchar(500) NOT NULL,
  `sdescription` varchar(500) NOT NULL,
  `status` enum('0','1') NOT NULL COMMENT '"0:Inactive","1:Active"',
  `file` varchar(250) NOT NULL,
  `p_id` int(11) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_name`, `description`, `sdescription`, `status`, `file`, `p_id`) VALUES
(1, ' Mobile', 'hh', 'hh', '1', '51374-mobiles.jpg', 0),
(2, ' laptop', 'll', 'll', '1', '14583-laptops.jpg', 0),
(5, ' Sony', 'hh', 'hh', '1', '51122-sony.jpg', 1),
(6, 'Dell', 'll', 'll', '1', '83747-download.jpg', 2),
(35, 'canon', 'asd', 'wre', '1', '50540-camera.jpg', 37),
(37, 'Camera', 'll', 'll', '1', '62721-cameras.jpg', 0),
(42, 'samsung', 'pp', 'pp', '1', '82488-samsung.jpg', 1),
(43, 'Television', 'kk', 'kk', '1', '95203-tv.jpg', 0),
(44, 'LG', 'pp', 'pp', '1', '88051-lg.jpg', 43),
(45, 'Lenovo', 'lenovo laptops', 'lenovo laptops', '1', '23905-lenovolappy.jpg', 2),
(46, 'Nikon', 'Nikon coolpix 510', 'lenovo laptops', '1', '67901-nikon.jpg', 37),
(47, 'Sony Bravia', 'sony bravia 120', 'sony bravia120', '1', '30733-bravia.jpg', 43),
(48, 'lg', 'lg tv', 'lg tv', '1', '56208-lg.jpg', 43);

-- --------------------------------------------------------

--
-- Table structure for table `formtest`
--

CREATE TABLE IF NOT EXISTS `formtest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `state` varchar(20) NOT NULL,
  `file` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `formtest`
--

INSERT INTO `formtest` (`id`, `fullname`, `dob`, `gender`, `state`, `file`) VALUES
(11, 'Steve  Jobs', '1995-01-01', 'Male', 'Gujarat', '18886-jobs.jpg'),
(12, 'Bill  Gates', '1995-02-01', 'Male', 'Maharashtra', '42943-bill.jpg'),
(15, 'shah rukh khan', '1995-02-02', 'Male', 'Gujarat', '58720-srk.jpg'),
(19, 'Mahendra singh Dhoni', '1996-02-01', 'Male', 'Maharashtra', '25395-msd.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `uname`, `password`) VALUES
(1, 'Raj', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `login_user`
--

CREATE TABLE IF NOT EXISTS `login_user` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(30) NOT NULL,
  `user_password` varchar(30) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `login_user`
--

INSERT INTO `login_user` (`u_id`, `user_name`, `user_password`) VALUES
(1, 'rajmistry', '12345'),
(2, 'meetshah', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `pr_id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `Short_description` varchar(500) NOT NULL,
  `price` int(11) NOT NULL,
  `file` varchar(250) NOT NULL,
  `category` varchar(20) NOT NULL,
  `sub_category` varchar(20) NOT NULL,
  `p_status` enum('0','1') NOT NULL,
  `Inventory` int(11) NOT NULL,
  PRIMARY KEY (`pr_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pr_id`, `Name`, `Description`, `Short_description`, `price`, `file`, `category`, `sub_category`, `p_status`, `Inventory`) VALUES
(1, 'samsung x2001', 'll', 'll', 20000, '60639-samsung.jpg', '1', '42', '0', 475),
(2, 'sony z', 'll', 'll', 15000, '18375-sony.jpg', '1', '5', '0', 471),
(3, 'nikon coolpix 110', 'pp', 'pp', 34000, '39783-coolpix.jpg', '37', '46', '1', 699),
(4, 'galaxy Grand 2', 'll', 'll', 25000, '68747-samsung.jpg', '1', '42', '0', 800);

-- --------------------------------------------------------

--
-- Table structure for table `review_order`
--

CREATE TABLE IF NOT EXISTS `review_order` (
  `re_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(30) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `email` varchar(20) NOT NULL,
  `telephone` int(11) NOT NULL,
  `address` varchar(100) NOT NULL,
  `country` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `zip` int(11) NOT NULL,
  `state` varchar(20) NOT NULL,
  `company` varchar(50) NOT NULL,
  `fax` int(11) NOT NULL,
  `card_name` varchar(30) NOT NULL,
  `card_type` varchar(20) NOT NULL,
  `card_num` int(11) NOT NULL,
  `exp_date` date NOT NULL,
  `shipping_method` varchar(30) NOT NULL,
  `payment_method` varchar(30) NOT NULL,
  `status` int(11) NOT NULL,
  `u_id` int(11) NOT NULL,
  PRIMARY KEY (`re_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=61 ;

--
-- Dumping data for table `review_order`
--

INSERT INTO `review_order` (`re_id`, `order_id`, `fullname`, `email`, `telephone`, `address`, `country`, `city`, `zip`, `state`, `company`, `fax`, `card_name`, `card_type`, `card_num`, `exp_date`, `shipping_method`, `payment_method`, `status`, `u_id`) VALUES
(1, '9185976471', 'Meet Shah', 'meet@gmail.com', 2147483647, 'A-2, Shakti apartment beside suryanagar', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(2, '6553231058', 'Meet Shah', 'meet@gmail.com', 2147483647, 'A-2, Shakti apartment beside suryanagar', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(3, '67286231', 'Meet Shah', 'meet@gmail.com', 2147483647, 'A-2, Shakti apartment beside suryanagar', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(4, '1936914854', 'Meet Shah', 'meet@gmail.com', 2147483647, 'A-2, Shakti apartment beside suryanagar', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(5, '3103344219', 'Meet Shah', 'meet@gmail.com', 2147483647, 'A-2, Shakti apartment beside suryanagar', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(6, '2461748284', 'raj mistry', '', 2147483647, 'jjj jjj', 'India', 'ahmedabad', 380005, 'gujarat', 'biztech', 96015, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(7, '1428712549', 'raj mistry', 'raj@gmail.com', 960156987, 'jjj jjj', 'India', 'ahmedabad', 380005, 'gujarat', 'biztech', 96015, '', '', 0, '0000-00-00', 'Flat rate- Express Shipping', 'CASH ON DELIVERY', 0, 0),
(8, '5719500598', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate- Express Shipping', 'CASH ON DELIVERY', 0, 0),
(9, '7697598052', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(10, '3394994533', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(11, '5971100656', 'Meet Shah', 'meet@gmail.com', 2147483647, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate- Express Shipping', 'CASH ON DELIVERY', 0, 0),
(12, '3482771234', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(13, '157651799', 'Meet Shah', 'meet@gmail.com', 2147483647, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(14, '7412621121', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate- Express Shipping', 'CASH ON DELIVERY', 0, 0),
(15, '4649826638', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(16, '3846690116', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(17, '9545768631', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(18, '2750455577', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(19, '4154395085', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(20, '6900878980', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(21, '5377170714', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(22, '1125476918', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(23, '7149233011', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 0),
(24, '994212189', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(25, '9250870055', 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 2),
(26, '4216952404', 'Dishan Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 2),
(27, '582484211', 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 2),
(28, '9463903202', 'Dishant Mod', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 2),
(29, '697059840', 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 2),
(30, '6375456787', 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 2),
(31, '9454805973', 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 2),
(32, '3412283759', 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 2),
(33, '4814275769', 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548, '', '', 0, '0000-00-00', 'Flat rate- Express Shipping', 'CASH ON DELIVERY', 0, 2),
(34, '9386982761', 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 2),
(35, '9724673369', 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 2),
(36, '1730048003', 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 2),
(37, '260774610', 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 2),
(38, '8065122177', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(39, '7115039065', 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 2),
(40, '2318429945', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(41, '3279311361', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate- Express Shipping', 'CASH ON DELIVERY', 0, 1),
(42, '5558199272', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(43, '8740202134', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(44, '4501579409', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(45, '380148529', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(46, '6874846610', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(47, '8833987575', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(48, '862420392', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(49, '5807704567', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(50, '9843997933', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(51, '2117916176', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(52, '8474350019', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(53, '2883348709', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(54, '6677299262', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(55, '1493894811', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(56, '3197119820', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(57, '1787938251', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(58, '5245280708', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(59, '1755948624', 'Meet Shah', 'meet@gmail.com', 989858574, 'A-2, Shakti apartment beside suryanagar ', 'India', 'ahmedabad', 7777777, 'gujarat', 'tatvasoft', 98985, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 1),
(60, '807698275', 'Dishant Modi', 'modi@gmail.com', 2147483647, 'B-1, Pooja apartmrnt mehsana ', 'India', 'mehsana', 7777777, 'gujarat', 'tatvasoft', 78548, '', '', 0, '0000-00-00', 'Flat rate-fixed', 'CASH ON DELIVERY', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `review_order_product`
--

CREATE TABLE IF NOT EXISTS `review_order_product` (
  `re_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(30) NOT NULL,
  `image` varchar(250) NOT NULL,
  `price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL,
  `order_id` varchar(30) NOT NULL,
  PRIMARY KEY (`re_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `review_order_product`
--

INSERT INTO `review_order_product` (`re_id`, `product_name`, `image`, `price`, `quantity`, `subtotal`, `order_id`) VALUES
(1, 'sony z', '18375-sony.jpg', 15000, 1, 15000, '6553231058'),
(2, 'samsung x2001', '60639-samsung.jpg', 20000, 2, 40000, '6553231058'),
(3, 'sony z', '18375-sony.jpg', 15000, 11, 165000, '67286231'),
(4, 'sony z', '18375-sony.jpg', 15000, 3, 45000, '3103344219'),
(5, 'samsung x2001', '60639-samsung.jpg', 20000, 2, 40000, '3103344219'),
(6, 'sony z', '18375-sony.jpg', 15000, 3, 45000, '2461748284'),
(7, 'samsung x2001', '60639-samsung.jpg', 20000, 2, 40000, '2461748284'),
(8, 'sony z', '18375-sony.jpg', 15000, 1, 15000, '1428712549'),
(9, 'sony z', '18375-sony.jpg', 15000, 1, 15000, '5719500598'),
(10, 'sony z', '18375-sony.jpg', 15000, 1, 15000, '7697598052'),
(11, 'sony z', '18375-sony.jpg', 15000, 1, 15000, '3394994533'),
(12, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '5971100656'),
(13, 'sony z', '18375-sony.jpg', 15000, 6, 90000, '3482771234'),
(14, 'samsung x2001', '60639-samsung.jpg', 20000, 4, 80000, '3482771234'),
(15, 'galaxy Grand 2', '68747-samsung.jpg', 25000, 4, 100000, '157651799'),
(16, 'sony z', '18375-sony.jpg', 15000, 1, 15000, '157651799'),
(17, 'sony z', '18375-sony.jpg', 15000, 455, 6825000, '7412621121'),
(18, 'sony z', '18375-sony.jpg', 15000, 412, 6180000, '4649826638'),
(19, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '3846690116'),
(20, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '9545768631'),
(21, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '2750455577'),
(22, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '4154395085'),
(23, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '6900878980'),
(24, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '5377170714'),
(25, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '1125476918'),
(26, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '7149233011'),
(27, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '994212189'),
(28, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '9250870055'),
(29, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '4216952404'),
(30, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '582484211'),
(31, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '9463903202'),
(32, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '697059840'),
(33, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '6375456787'),
(34, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '9454805973'),
(35, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '3412283759'),
(36, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '4814275769'),
(37, 'sony z', '18375-sony.jpg', 15000, 1, 15000, '9386982761'),
(38, 'samsung x2001', '60639-samsung.jpg', 20000, 3, 60000, '9386982761'),
(39, 'samsung x2001', '60639-samsung.jpg', 20000, 1, 20000, '9724673369'),
(40, 'sony z', '18375-sony.jpg', 15000, 3, 45000, '9724673369'),
(41, 'sony z', '18375-sony.jpg', 15000, 3, 45000, '260774610'),
(42, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '8065122177'),
(43, 'sony z', '18375-sony.jpg', 15000, 3, 45000, '7115039065'),
(44, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '2318429945'),
(45, 'sony z', '18375-sony.jpg', 15000, 3, 45000, '3279311361'),
(46, 'sony z', '18375-sony.jpg', 15000, 3, 45000, '5558199272'),
(47, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '8740202134'),
(48, 'samsung x2001', '60639-samsung.jpg', 20000, 2, 40000, '8740202134'),
(49, 'sony z', '18375-sony.jpg', 15000, 1, 15000, '4501579409'),
(50, 'sony z', '18375-sony.jpg', 15000, 5, 75000, '380148529'),
(51, 'nikon coolpix 110', '39783-coolpix.jpg', 34000, 1, 34000, '8833987575'),
(52, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '5245280708'),
(53, 'sony z', '18375-sony.jpg', 15000, 2, 30000, '1755948624'),
(54, 'sony z', '18375-sony.jpg', 15000, 3, 45000, '807698275');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
